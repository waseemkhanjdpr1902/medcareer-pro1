# MedCareer Pro 🩺

**The complete AI-powered career platform for healthcare professionals.**

Track CME credits · Build ATS-optimized CVs · AI career guidance · Mock interview practice  
Built with **Next.js 14 App Router**, **Supabase**, **Anthropic Claude**, and **Razorpay**.

---

## ✨ Feature Matrix

| Feature | Basic (Free) | Professional ₹999/mo | Premium ₹1,999/mo |
|---------|:-----------:|:-------------------:|:-----------------:|
| CME Tracking | 10 entries | Unlimited | Unlimited |
| CV Score/month | 1 | 10 | Unlimited |
| CV Builder | 1 template | 3 + AI Optimize | Unlimited |
| Career Guidance | 3 sessions | Unlimited | Unlimited |
| Mock Interviews | 2/month | 15/month | Unlimited |
| Analytics | ❌ | ✅ | ✅ |
| PDF/CSV Export | ❌ | ✅ | ✅ |
| Priority Support | ❌ | ❌ | ✅ |

---

## ⚙️ Quick Setup

### 1  Install dependencies
```bash
unzip medcareer-pro.zip && cd medcareer-pro && npm install
```

### 2  Environment variables
```bash
cp .env.example .env.local
# Fill in: SUPABASE keys, ANTHROPIC_API_KEY, RAZORPAY keys
```

### 3  Database
Go to https://app.supabase.com/project/sspruywktrnvyccsbadk → SQL Editor  
Run migrations in order:
- `supabase/migrations/001_schema.sql`
- `supabase/migrations/002_functions_indexes.sql`

### 4  Auth redirect URLs (Supabase Dashboard)
- Site URL: `http://localhost:3000`
- Redirect URL: `http://localhost:3000/auth/callback`

### 5  Run
```bash
npm run dev   # http://localhost:3000
```

---

## 🚀 Deploy (Vercel)
```bash
npx vercel
# Set all .env.local vars in Vercel → Settings → Environment Variables
# Update Supabase Site URL and Razorpay origins to production domain
```

---

## 💳 Payment Flow
1. User clicks Subscribe → `POST /api/create-order` creates Razorpay order
2. Razorpay checkout opens (client SDK)
3. On success → `POST /api/verify-payment` (HMAC-SHA256 verification)
4. `profiles` table updated with new tier + dates
5. Webhooks at `/api/webhook/razorpay` handle cancellations

---

## 🔒 Security
- All API routes require authenticated Supabase session
- RLS enabled on all 8 database tables
- Payment verified server-side with HMAC signature
- Service role key never exposed to browser

---

## 📞 Support: support@medcareerpro.in
