'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { CheckCircle2, Loader2, Zap, Shield, Clock, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { PRICING } from '@/lib/utils';
import { getSupabase } from '@/lib/supabase-client';

declare global {
  interface Window {
    Razorpay: any;
  }
}

const PLANS = [
  {
    key: 'professional',
    name: 'Professional',
    monthlyPrice: '₹999',
    yearlyPrice: '₹833',
    yearlyTotal: '₹9,999',
    color: 'border-teal-500',
    badgeColor: 'bg-teal-500',
    badge: 'Most Popular',
    features: [
      'Unlimited CME tracking & reminders',
      '10 CV score checks per month',
      '3 AI-optimized CV templates',
      'Unlimited career guidance sessions',
      '15 mock interview sessions/month',
      'AI CV keyword optimization',
      'Advanced analytics dashboard',
      'PDF export & sharing',
    ],
  },
  {
    key: 'premium',
    name: 'Premium',
    monthlyPrice: '₹1,999',
    yearlyPrice: '₹1,666',
    yearlyTotal: '₹19,999',
    color: 'border-yellow-500',
    badgeColor: 'bg-yellow-500',
    badge: 'Best Value',
    features: [
      'Everything in Professional',
      'Unlimited CV score checks',
      'Unlimited CV builders',
      'Unlimited mock interviews',
      'Fellowship application guidance',
      'Specialty-specific interview prep',
      'Salary benchmarking data',
      'Priority 24/7 support',
    ],
  },
];

function PricingContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const planParam = searchParams.get('plan') || 'professional';
  const billingParam = searchParams.get('billing') || 'monthly';

  const [selectedPlan, setSelectedPlan] = useState(planParam);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>(billingParam as 'monthly' | 'yearly');
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const loadScript = () => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.async = true;
      document.body.appendChild(script);
    };
    loadScript();

    const getUser = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
    };
    getUser();
  }, []);

  const handleSubscribe = async (planKey: string) => {
    if (!user) {
      router.push(`/auth/signup?plan=${planKey}&billing=${billingCycle}`);
      return;
    }

    setLoading(true);
    try {
      const orderRes = await fetch('/api/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: planKey, billing_cycle: billingCycle }),
      });
      const orderData = await orderRes.json();
      if (orderData.error) throw new Error(orderData.error);

      const options = {
        key: orderData.key_id,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'MedCareer Pro',
        description: `${planKey.charAt(0).toUpperCase() + planKey.slice(1)} Plan — ${billingCycle === 'yearly' ? 'Annual' : 'Monthly'} Subscription`,
        image: '/logo.png',
        order_id: orderData.order_id,
        prefill: {
          name: orderData.user.name,
          email: orderData.user.email,
          contact: orderData.user.phone,
        },
        theme: { color: '#0D9DA4' },
        handler: async (response: any) => {
          const verifyRes = await fetch('/api/verify-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              plan: planKey,
              billing_cycle: billingCycle,
            }),
          });
          const verifyData = await verifyRes.json();
          if (verifyData.success) {
            router.push('/dashboard?payment=success');
          } else {
            alert('Payment verification failed. Please contact support.');
          }
        },
        modal: {
          ondismiss: () => setLoading(false),
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on('payment.failed', () => {
        alert('Payment failed. Please try again.');
        setLoading(false);
      });
      rzp.open();
    } catch (error: any) {
      alert(error.message || 'Something went wrong. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-medical-bg">
      {/* Header */}
      <div className="bg-white border-b border-medical-border px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2 text-gray-600 hover:text-navy-600 transition-colors">
            <ArrowLeft size={18} />
            <span className="text-sm font-medium">Back to Dashboard</span>
          </Link>
          <div className="flex items-center gap-2">
            <Shield size={16} className="text-teal-500" />
            <span className="text-xs text-gray-500">Secured by Razorpay</span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <h1 className="font-display text-4xl font-bold text-gray-900 mb-3">Upgrade Your Plan</h1>
          <p className="text-gray-500 text-lg">Unlock the full power of AI-driven medical career tools</p>

          {/* Billing toggle */}
          <div className="inline-flex bg-white rounded-xl p-1 border border-gray-200 shadow-sm mt-6">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${billingCycle === 'monthly' ? 'bg-navy-600 text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${billingCycle === 'yearly' ? 'bg-navy-600 text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
            >
              Yearly
              <span className={`text-xs px-2 py-0.5 rounded-full ${billingCycle === 'yearly' ? 'bg-white/20 text-white' : 'bg-green-100 text-green-700'}`}>Save 17%</span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {PLANS.map(plan => (
            <div
              key={plan.key}
              className={`bg-white rounded-2xl border-2 ${selectedPlan === plan.key ? plan.color : 'border-gray-200'} p-8 relative cursor-pointer transition-all shadow-card hover:shadow-card-hover`}
              onClick={() => setSelectedPlan(plan.key)}
            >
              <div className={`absolute -top-4 left-6 px-4 py-1 rounded-full text-xs font-bold text-white ${plan.badgeColor}`}>
                {plan.badge}
              </div>

              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-display text-2xl font-bold text-gray-900">{plan.name}</h3>
                  <div className="mt-2">
                    <span className="font-display text-4xl font-bold text-gray-900">
                      {billingCycle === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice}
                    </span>
                    <span className="text-gray-500 text-sm">/month</span>
                    {billingCycle === 'yearly' && (
                      <p className="text-xs text-green-600 font-medium mt-1">Billed as {plan.yearlyTotal}/year</p>
                    )}
                  </div>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selectedPlan === plan.key ? 'bg-teal-500 border-teal-500' : 'border-gray-300'}`}>
                  {selectedPlan === plan.key && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
                </div>
              </div>

              <ul className="space-y-2.5 mb-6">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-gray-700">
                    <CheckCircle2 size={15} className="text-teal-500 flex-shrink-0 mt-0.5" strokeWidth={2.5} />
                    {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={(e) => { e.stopPropagation(); handleSubscribe(plan.key); }}
                disabled={loading}
                className={`w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  plan.key === 'professional'
                    ? 'bg-teal-500 text-white hover:bg-teal-600'
                    : 'bg-yellow-500 text-white hover:bg-yellow-600'
                } disabled:opacity-50`}
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                {loading ? 'Processing...' : `Subscribe to ${plan.name}`}
              </button>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <Shield size={16} className="text-green-500" />
            <span>256-bit SSL encryption</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 size={16} className="text-green-500" />
            <span>7-day free trial</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-green-500" />
            <span>Cancel anytime</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-green-500" />
            <span>Instant activation</span>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          By subscribing, you agree to our Terms of Service and Privacy Policy. Payments processed securely by Razorpay.
          You can cancel at any time from your Account settings.
        </p>
      </div>
    </div>
  );
}

export default function PricingPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>}>
      <PricingContent />
    </Suspense>
  );
}
