import type { Metadata } from 'next';
import './globals.css';
import { ToastProvider } from '@/components/toast';

export const metadata: Metadata = {
  title: {
    default: 'MedCareer Pro — Healthcare Professional Career Platform',
    template: '%s | MedCareer Pro',
  },
  description: 'Track CME credits, build ATS-optimized CVs, get AI career guidance, and practice mock interviews. The complete career platform for healthcare professionals.',
  keywords: ['CME tracker', 'medical CV builder', 'healthcare career', 'ATS CV', 'medical mock interview', 'doctor career guidance'],
  authors: [{ name: 'MedCareer Pro' }],
  openGraph: {
    type: 'website',
    siteName: 'MedCareer Pro',
    title: 'MedCareer Pro — Healthcare Professional Career Platform',
    description: 'The complete AI-powered career platform for healthcare professionals.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="font-body antialiased">
        <ToastProvider>
          {children}
        </ToastProvider>
      </body>
    </html>
  );
}
