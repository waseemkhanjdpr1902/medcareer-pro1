'use client';

import { useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { CheckCircle2, Zap, ArrowRight, Loader2 } from 'lucide-react';
import Link from 'next/link';
import confetti from 'canvas-confetti';

function PaymentSuccessContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const plan = searchParams.get('plan') || 'professional';

  useEffect(() => {
    // Fire confetti
    const end = Date.now() + 2500;
    const colors = ['#0D9DA4', '#0A4B6E', '#F5A623'];
    const frame = () => {
      confetti({ particleCount: 3, angle: 60, spread: 55, origin: { x: 0 }, colors });
      confetti({ particleCount: 3, angle: 120, spread: 55, origin: { x: 1 }, colors });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    try { frame(); } catch {}
    const t = setTimeout(() => router.push('/dashboard'), 6000);
    return () => clearTimeout(t);
  }, [router]);

  const planFeatures: Record<string, string[]> = {
    professional: [
      'Unlimited CME tracking activated',
      '10 CV score checks per month',
      'Unlimited AI career guidance',
      '15 mock interview sessions/month',
    ],
    premium: [
      'Unlimited everything — activated!',
      'Priority 24/7 support',
      'Fellowship application tools',
      'Salary benchmarking data',
    ],
  };

  const features = planFeatures[plan] || planFeatures.professional;

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-600 via-navy-700 to-teal-700 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-10 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} className="text-green-500" />
        </div>
        <h1 className="font-display text-3xl font-bold text-gray-900 mb-2">
          Welcome to {plan.charAt(0).toUpperCase() + plan.slice(1)}!
        </h1>
        <p className="text-gray-500 mb-8">
          Your subscription is active. All premium features are now unlocked.
        </p>

        <div className="bg-gray-50 rounded-2xl p-5 mb-8 text-left space-y-3">
          {features.map((f) => (
            <div key={f} className="flex items-center gap-3">
              <div className="w-5 h-5 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 size={12} className="text-teal-600" />
              </div>
              <span className="text-sm text-gray-700">{f}</span>
            </div>
          ))}
        </div>

        <Link
          href="/dashboard"
          className="btn-teal w-full py-3.5 text-base flex items-center justify-center gap-2"
        >
          <Zap size={18} />
          Go to Dashboard
          <ArrowRight size={16} />
        </Link>
        <p className="text-xs text-gray-400 mt-4">
          Redirecting automatically in a few seconds…
        </p>
      </div>
    </div>
  );
}

export default function PaymentSuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-navy-600">
        <Loader2 className="text-white animate-spin" size={32} />
      </div>
    }>
      <PaymentSuccessContent />
    </Suspense>
  );
}
