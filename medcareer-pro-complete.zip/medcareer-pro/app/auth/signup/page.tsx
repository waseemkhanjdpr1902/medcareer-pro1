'use client';

import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Stethoscope, Eye, EyeOff, Loader2, CheckCircle2 } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { MEDICAL_SPECIALTIES } from '@/lib/utils';

function SignupForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const plan = searchParams.get('plan') || 'basic';
  const billing = searchParams.get('billing') || 'monthly';

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [form, setForm] = useState({
    full_name: '',
    email: '',
    password: '',
    specialty: '',
    designation: '',
    years_of_experience: '',
  });

  const update = (field: string, value: string) => setForm(p => ({ ...p, [field]: value }));

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) { setStep(2); return; }

    setError('');
    setLoading(true);
    const supabase = getSupabase();

    const { data, error: signupError } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        data: {
          full_name: form.full_name,
          specialty: form.specialty,
          designation: form.designation,
          years_of_experience: parseInt(form.years_of_experience) || 0,
        }
      }
    });

    if (signupError) {
      setError(signupError.message);
      setLoading(false);
      return;
    }

    if (data.user) {
      await supabase.from('profiles').upsert({
        id: data.user.id,
        full_name: form.full_name,
        email: form.email,
        specialty: form.specialty,
        designation: form.designation,
        years_of_experience: parseInt(form.years_of_experience) || 0,
        onboarding_completed: true,
      });

      if (plan !== 'basic') {
        router.push(`/pricing?plan=${plan}&billing=${billing}`);
      } else {
        router.push('/dashboard');
      }
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-medical-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-navy-600 rounded-xl flex items-center justify-center">
              <Stethoscope size={20} className="text-white" />
            </div>
            <span className="font-display text-2xl font-bold text-navy-600">MedCareer Pro</span>
          </Link>
          <h1 className="font-display text-3xl font-bold text-gray-900">
            {step === 1 ? 'Create your account' : 'Your professional profile'}
          </h1>
          <p className="text-gray-500 mt-2">
            {step === 1 ? 'Start your career transformation today' : 'Help us personalize your experience'}
          </p>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-3 mb-6 justify-center">
          {[1, 2].map(s => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                s < step ? 'bg-teal-500 text-white' : s === step ? 'bg-navy-600 text-white' : 'bg-gray-200 text-gray-400'
              }`}>
                {s < step ? <CheckCircle2 size={14} /> : s}
              </div>
              {s < 2 && <div className={`w-8 h-0.5 ${s < step ? 'bg-teal-500' : 'bg-gray-200'}`} />}
            </div>
          ))}
        </div>

        <div className="card">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm mb-6">
              {error}
            </div>
          )}

          {plan !== 'basic' && (
            <div className="bg-teal-50 border border-teal-200 rounded-lg px-4 py-3 text-sm text-teal-700 mb-6">
              🎉 You're signing up for the <strong>{plan.charAt(0).toUpperCase() + plan.slice(1)}</strong> plan — 7 days free trial included!
            </div>
          )}

          <form onSubmit={handleSignup} className="space-y-5">
            {step === 1 ? (
              <>
                <div>
                  <label className="label">Full Name</label>
                  <input required value={form.full_name} onChange={e => update('full_name', e.target.value)} className="input-field" placeholder="Dr. Jane Smith" />
                </div>
                <div>
                  <label className="label">Email address</label>
                  <input type="email" required value={form.email} onChange={e => update('email', e.target.value)} className="input-field" placeholder="doctor@hospital.com" />
                </div>
                <div>
                  <label className="label">Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={form.password}
                      onChange={e => update('password', e.target.value)}
                      className="input-field pr-10"
                      placeholder="Min 8 characters"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <button type="submit" className="btn-primary w-full py-3">Continue</button>
              </>
            ) : (
              <>
                <div>
                  <label className="label">Medical Specialty</label>
                  <select required value={form.specialty} onChange={e => update('specialty', e.target.value)} className="input-field">
                    <option value="">Select your specialty</option>
                    {MEDICAL_SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Current Designation</label>
                  <select required value={form.designation} onChange={e => update('designation', e.target.value)} className="input-field">
                    <option value="">Select designation</option>
                    {['Medical Student', 'Intern', 'Junior Resident', 'Senior Resident', 'Fellow', 'Registrar', 'Consultant', 'Associate Professor', 'Professor', 'HOD/Director', 'Retired'].map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Years of Experience</label>
                  <input type="number" min={0} max={50} value={form.years_of_experience} onChange={e => update('years_of_experience', e.target.value)} className="input-field" placeholder="0" />
                </div>
                <button type="submit" disabled={loading} className="btn-primary w-full py-3 flex items-center justify-center gap-2">
                  {loading ? <Loader2 size={16} className="animate-spin" /> : null}
                  {loading ? 'Creating account...' : 'Create my account'}
                </button>
                <button type="button" onClick={() => setStep(1)} className="w-full text-center text-sm text-gray-500 hover:text-gray-700">← Back</button>
              </>
            )}
          </form>

          <p className="text-center text-sm text-gray-500 mt-6">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-teal-600 font-semibold hover:text-teal-700">Sign in</Link>
          </p>
          <p className="text-center text-xs text-gray-400 mt-4">
            By creating an account, you agree to our{' '}
            <a href="#" className="underline">Terms</a> and <a href="#" className="underline">Privacy Policy</a>.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function SignupPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>}>
      <SignupForm />
    </Suspense>
  );
}
