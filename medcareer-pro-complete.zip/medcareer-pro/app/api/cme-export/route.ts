import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

export async function GET(req: NextRequest) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { data: records, error } = await supabase
      .from('cme_records')
      .select('*')
      .eq('user_id', user.id)
      .order('completion_date', { ascending: false });

    if (error) throw error;

    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name, subscription_tier')
      .eq('id', user.id)
      .single();

    if (profile?.subscription_tier === 'basic') {
      return NextResponse.json({ error: 'CSV export requires Professional or Premium plan.' }, { status: 403 });
    }

    // Build CSV
    const headers = [
      'Title', 'Provider', 'Activity Type', 'Credits', 'Credit Type',
      'Completion Date', 'Expiry Date', 'Mandatory', 'Verification Status', 'Notes'
    ];

    const rows = (records || []).map(r => [
      csvEscape(r.title),
      csvEscape(r.provider),
      csvEscape(r.activity_type),
      r.credits,
      csvEscape(r.credit_type),
      r.completion_date,
      r.expiry_date || '',
      r.is_mandatory ? 'Yes' : 'No',
      csvEscape(r.verification_status),
      csvEscape(r.notes || ''),
    ]);

    const totalCredits = (records || []).reduce((s, r) => s + parseFloat(r.credits), 0);

    const csv = [
      `# MedCareer Pro — CME Export for ${profile?.full_name || ''}`,
      `# Generated: ${new Date().toLocaleDateString('en-IN')}`,
      `# Total Records: ${records?.length || 0} | Total Credits: ${totalCredits.toFixed(1)}`,
      '',
      headers.join(','),
      ...rows.map(r => r.join(',')),
    ].join('\n');

    return new NextResponse(csv, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="cme-export-${new Date().toISOString().slice(0, 10)}.csv"`,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

function csvEscape(value: string): string {
  if (!value) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}
