import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';
import { createServiceClient } from '@/lib/supabase-server';
import crypto from 'crypto';

export async function POST(req: NextRequest) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan, billing_cycle } = await req.json();

    // Verify signature
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      return NextResponse.json({ error: 'Invalid payment signature' }, { status: 400 });
    }

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    // Calculate subscription period
    const now = new Date();
    const endDate = new Date(now);
    if (billing_cycle === 'yearly') {
      endDate.setFullYear(endDate.getFullYear() + 1);
    } else {
      endDate.setMonth(endDate.getMonth() + 1);
    }

    const serviceSupabase = createServiceClient();

    // Insert subscription record
    await serviceSupabase.from('subscriptions').insert({
      user_id: user.id,
      razorpay_order_id,
      razorpay_payment_id,
      plan_id: `${plan}_${billing_cycle}`,
      plan_name: plan,
      billing_cycle,
      amount: billing_cycle === 'yearly' ? (plan === 'professional' ? 999900 : 1999900) : (plan === 'professional' ? 99900 : 199900),
      currency: 'INR',
      status: 'active',
      current_period_start: now.toISOString(),
      current_period_end: endDate.toISOString(),
    });

    // Update user profile
    await serviceSupabase.from('profiles').update({
      subscription_tier: plan,
      subscription_status: 'active',
      subscription_start_date: now.toISOString(),
      subscription_end_date: endDate.toISOString(),
    }).eq('id', user.id);

    return NextResponse.json({ success: true, message: 'Subscription activated successfully!' });
  } catch (error: any) {
    console.error('Verify payment error:', error);
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 500 });
  }
}
