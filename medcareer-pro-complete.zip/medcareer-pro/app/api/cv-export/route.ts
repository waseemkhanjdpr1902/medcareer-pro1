import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// Generates a clean HTML CV that the browser can print-to-PDF.
// Returns HTML so the client can trigger window.print() or blob download.
export async function POST(req: NextRequest) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    // Check plan
    const { data: profile } = await supabase
      .from('profiles')
      .select('subscription_tier, full_name, specialty')
      .eq('id', user.id)
      .single();

    if (profile?.subscription_tier === 'basic') {
      return NextResponse.json({ error: 'PDF export requires Professional or Premium plan.' }, { status: 403 });
    }

    const { cv_id } = await req.json();

    const query = cv_id
      ? supabase.from('cv_data').select('*').eq('id', cv_id).eq('user_id', user.id).single()
      : supabase.from('cv_data').select('*').eq('user_id', user.id).eq('is_primary', true).single();

    const { data: cv, error } = await query;
    if (error || !cv) return NextResponse.json({ error: 'CV not found' }, { status: 404 });

    const html = buildCvHtml(cv);
    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'X-CV-Name': encodeURIComponent(profile?.full_name || 'CV'),
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

function fmtDate(str: string) {
  if (!str) return '';
  const d = new Date(str + '-01');
  return d.toLocaleString('default', { month: 'short', year: 'numeric' });
}

function buildCvHtml(cv: any): string {
  const p = cv.personal_info || {};
  const esc = (s: string) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const section = (title: string, content: string) =>
    content.trim()
      ? `<section class="section"><h2 class="section-title">${esc(title)}</h2><div class="divider"></div>${content}</section>`
      : '';

  const workExp = (cv.work_experience || []).map((e: any) => `
    <div class="entry">
      <div class="entry-header">
        <span class="entry-title">${esc(e.position)}${e.department ? ` — ${esc(e.department)}` : ''}</span>
        <span class="entry-dates">${e.start_date ? fmtDate(e.start_date) : ''}${e.end_date ? ` – ${esc(e.end_date) === '' ? 'Present' : fmtDate(e.end_date)}` : ' – Present'}</span>
      </div>
      <p class="entry-sub">${esc(e.institution)}</p>
      ${e.description ? `<div class="entry-desc">${esc(e.description).replace(/\n/g, '<br/>')}</div>` : ''}
    </div>`).join('');

  const education = (cv.education || []).map((e: any) => `
    <div class="entry">
      <div class="entry-header">
        <span class="entry-title">${esc(e.degree)}${e.specialization ? ` in ${esc(e.specialization)}` : ''}</span>
        <span class="entry-dates">${e.year || ''}</span>
      </div>
      <p class="entry-sub">${esc(e.institution)}${e.score ? ` · ${esc(e.score)}` : ''}</p>
    </div>`).join('');

  const skills = (cv.skills || []).length
    ? `<div class="skills-grid">${(cv.skills || []).map((s: any) =>
        `<span class="skill-tag">${esc(s.name)}${s.level ? ` <span class="skill-level">(${esc(s.level)})</span>` : ''}</span>`
      ).join('')}</div>` : '';

  const pubs = (cv.publications || []).map((pub: any) => `
    <div class="pub-entry">
      <p class="pub-title">${esc(pub.title)}</p>
      <p class="pub-meta">${esc(pub.journal)}${pub.year ? `, ${esc(pub.year)}` : ''}${pub.authors ? ` · ${esc(pub.authors)}` : ''}${pub.doi ? ` · DOI: ${esc(pub.doi)}` : ''}</p>
    </div>`).join('');

  const certs = (cv.certifications || []).map((c: any) =>
    `<div class="inline-item"><strong>${esc(c.name)}</strong>${c.issuer ? ` · ${esc(c.issuer)}` : ''}${c.year ? ` (${esc(c.year)})` : ''}</div>`
  ).join('');

  const awards = (cv.awards || []).map((a: any) =>
    `<div class="inline-item"><strong>${esc(a.title)}</strong>${a.organization ? ` · ${esc(a.organization)}` : ''}${a.year ? ` (${esc(a.year)})` : ''}</div>`
  ).join('');

  const memberships = (cv.professional_memberships || []).map((m: any) =>
    `<div class="inline-item">${esc(m.name)}${m.year ? ` (${esc(m.year)})` : ''}</div>`
  ).join('');

  const languages = (cv.languages || []).map((l: any) =>
    `<span class="skill-tag">${esc(l.name)}${l.proficiency ? ` · ${esc(l.proficiency)}` : ''}</span>`
  ).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>${esc(p.full_name || 'Curriculum Vitae')}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;500;600&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Inter',sans-serif;font-size:10pt;color:#1a202c;background:#fff;line-height:1.5}
  .page{max-width:800px;margin:0 auto;padding:40px 48px}
  .header{border-bottom:2.5px solid #0A4B6E;padding-bottom:18px;margin-bottom:24px}
  .header h1{font-family:'Playfair Display',serif;font-size:26pt;color:#0A4B6E;letter-spacing:-0.5px}
  .contact-row{display:flex;flex-wrap:wrap;gap:12px;margin-top:8px;font-size:9pt;color:#4a5568}
  .contact-row a{color:#0D9DA4;text-decoration:none}
  .summary{background:#f0f9ff;border-left:3px solid #0D9DA4;padding:10px 14px;font-size:9.5pt;color:#2d3748;margin-bottom:20px;border-radius:0 6px 6px 0;line-height:1.6}
  .section{margin-bottom:20px}
  .section-title{font-family:'Playfair Display',serif;font-size:11pt;color:#0A4B6E;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:4px}
  .divider{height:1px;background:#e2e8f0;margin-bottom:12px}
  .entry{margin-bottom:12px}
  .entry-header{display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:4px}
  .entry-title{font-weight:600;font-size:10pt;color:#1a202c}
  .entry-dates{font-size:9pt;color:#718096;white-space:nowrap}
  .entry-sub{font-size:9.5pt;color:#4a5568;margin-top:2px;font-style:italic}
  .entry-desc{font-size:9pt;color:#4a5568;margin-top:5px;white-space:pre-line}
  .skills-grid{display:flex;flex-wrap:wrap;gap:6px}
  .skill-tag{background:#f0f9ff;border:1px solid #bee3f8;padding:3px 10px;border-radius:99px;font-size:8.5pt;color:#2b6cb0;font-weight:500}
  .skill-level{color:#90cdf4;font-weight:400}
  .pub-entry{margin-bottom:8px}
  .pub-title{font-weight:600;font-size:9.5pt;color:#1a202c}
  .pub-meta{font-size:9pt;color:#718096;margin-top:2px}
  .inline-item{font-size:9.5pt;color:#2d3748;margin-bottom:5px;padding-left:12px;position:relative}
  .inline-item::before{content:'▸';position:absolute;left:0;color:#0D9DA4;font-size:8pt}
  @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{padding:20px 28px}}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <h1>${esc(p.full_name || 'Your Name')}</h1>
    <div class="contact-row">
      ${p.email ? `<span>✉ <a href="mailto:${esc(p.email)}">${esc(p.email)}</a></span>` : ''}
      ${p.phone ? `<span>📞 ${esc(p.phone)}</span>` : ''}
      ${p.address ? `<span>📍 ${esc(p.address)}</span>` : ''}
      ${p.linkedin ? `<span>🔗 <a href="${esc(p.linkedin)}">${esc(p.linkedin)}</a></span>` : ''}
      ${p.website ? `<span>🌐 <a href="${esc(p.website)}">${esc(p.website)}</a></span>` : ''}
    </div>
  </div>
  ${cv.summary ? `<div class="summary">${esc(cv.summary)}</div>` : ''}
  ${section('Work Experience', workExp)}
  ${section('Education', education)}
  ${section('Skills', skills)}
  ${section('Publications', pubs)}
  ${section('Certifications & Licences', certs)}
  ${section('Awards & Honours', awards)}
  ${section('Professional Memberships', memberships)}
  ${languages ? section('Languages', `<div class="skills-grid">${languages}</div>`) : ''}
</div>
</body>
</html>`;
}
