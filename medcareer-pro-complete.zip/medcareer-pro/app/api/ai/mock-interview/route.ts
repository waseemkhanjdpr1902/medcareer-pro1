import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const INTERVIEWER_SYSTEM = `You are Dr. Interview, an experienced medical interviewer conducting a professional interview for healthcare positions. Your role:

INTERVIEW CONDUCT:
- Ask ONE question at a time (never multiple questions)
- Listen carefully to answers and ask follow-up questions
- Probe deeper when answers are vague or incomplete
- Maintain professional, neutral demeanor
- Vary between different question types (behavioral, situational, technical, motivational)
- For clinical interviews: present patient scenarios and ask for management plans
- Be appropriately challenging but fair

QUESTION TYPES TO USE:
- Behavioral: "Tell me about a time when..."
- Situational: "What would you do if..."
- Clinical: Present brief patient cases
- Motivational: "Why did you choose this specialty?"
- Scenario-based: "How would you handle a conflict with a senior colleague?"
- Technical: Questions relevant to the specialty/role

INTERVIEW FLOW:
1. Start with warm introduction and ice-breaker
2. Move to background/motivation questions
3. Progress to behavioral questions
4. Ask 1-2 technical/clinical questions
5. Near the end, ask about their questions (signals ending)

Keep your responses to 2-3 sentences maximum. Ask only ONE question.`;

const EVALUATOR_SYSTEM = `You are an expert medical interview evaluator. Based on the interview transcript provided, give a comprehensive performance evaluation as JSON.

Return ONLY this JSON structure:
{
  "overall_score": <0-100>,
  "summary": "<2-3 sentence overall assessment>",
  "strengths": ["strength1", "strength2", "strength3"],
  "improvements": ["area1", "area2", "area3"],
  "category_scores": {
    "communication": <0-100>,
    "clinical_knowledge": <0-100>,
    "professionalism": <0-100>,
    "self_awareness": <0-100>,
    "problem_solving": <0-100>
  },
  "specific_feedback": "<detailed 2-3 sentence feedback>",
  "recommended_practice": "<one specific thing to practice before next interview>"
}`;

export async function POST(req: NextRequest) {
  try {
    const { action, messages, interview_type, role_applied, specialty } = await req.json();

    if (action === 'start') {
      const prompt = `You are starting a ${interview_type} interview for a ${specialty || 'healthcare'} professional applying for: ${role_applied || 'a medical position'}.

Begin the interview with a warm, professional greeting, briefly introduce yourself as the interviewer, and ask your FIRST opening question. Keep it natural and welcoming.`;

      const response = await anthropic.messages.create({
        model: 'claude-opus-4-5',
        max_tokens: 300,
        system: INTERVIEWER_SYSTEM,
        messages: [{ role: 'user', content: prompt }],
      });

      return NextResponse.json({ response: (response.content[0] as any).text });
    }

    if (action === 'respond') {
      const anthropicMessages = messages.map((m: any) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      }));

      const userCount = messages.filter((m: any) => m.role === 'user').length;
      const systemNote = userCount >= 7
        ? `${INTERVIEWER_SYSTEM}\n\nNote: This interview is nearing its end (${userCount} questions answered). Begin wrapping up. Ask if they have any questions for you, then conclude professionally.`
        : INTERVIEWER_SYSTEM;

      const response = await anthropic.messages.create({
        model: 'claude-opus-4-5',
        max_tokens: 300,
        system: systemNote,
        messages: anthropicMessages,
      });

      return NextResponse.json({ response: (response.content[0] as any).text });
    }

    if (action === 'evaluate') {
      const transcript = messages.map((m: any) => `${m.role === 'user' ? 'CANDIDATE' : 'INTERVIEWER'}: ${m.content}`).join('\n\n');

      const evalPrompt = `Interview Type: ${interview_type}\nRole: ${role_applied || 'Medical Position'}\nSpecialty: ${specialty || 'General'}\n\nTRANSCRIPT:\n${transcript}\n\nEvaluate the candidate's interview performance.`;

      const response = await anthropic.messages.create({
        model: 'claude-opus-4-5',
        max_tokens: 1000,
        system: EVALUATOR_SYSTEM,
        messages: [{ role: 'user', content: evalPrompt }],
      });

      const responseText = (response.content[0] as any).text;
      const cleanJson = responseText.replace(/```json\n?|\n?```/g, '').trim();
      const evaluation = JSON.parse(cleanJson);

      return NextResponse.json({ evaluation });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('Mock interview API error:', error);
    return NextResponse.json({ response: 'I apologize for the interruption. Please continue with your answer.', evaluation: null }, { status: 500 });
  }
}
