import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are Dr. CareerPro, an expert AI career advisor specializing in healthcare professional career development. You have deep knowledge of:

- Indian medical career pathways (MBBS, MD, MS, DM, MCh, DNB, MRCP, USMLE, etc.)
- Fellowship programs (in India, USA, UK, Australia, and other countries)
- Hospital recruitment processes at AIIMS, Apollo, Fortis, Manipal, Medanta, and private/government hospitals
- Medical academia and research career paths
- Subspecialty trends and demand forecasts
- Salary benchmarks for various medical roles in India and abroad
- CV/resume optimization for medical professionals
- Interview preparation for residency, fellowship, and consultant positions
- NMC, MCI, and state medical council regulations
- Work-life balance and burnout prevention in healthcare

Your communication style:
- Professional yet warm and encouraging
- Provide specific, actionable advice
- Back recommendations with data/statistics where relevant
- Ask clarifying questions when needed
- Acknowledge the emotional challenges of medical careers
- Be direct and honest, avoid generic platitudes
- Tailor advice to the specific stage of their career

Always structure longer responses clearly with:
- Direct answer first
- Supporting details and examples
- Concrete next steps
- Keep responses focused (200-400 words unless detail is requested)`;

export async function POST(req: NextRequest) {
  try {
    const { messages, profile_context, session_type } = await req.json();

    const contextNote = profile_context?.specialty
      ? `\n[User context: ${profile_context.specialty} specialist, ${profile_context.designation || 'healthcare professional'}, ${profile_context.years || 0} years experience]`
      : '';

    const sessionNote = session_type && session_type !== 'general'
      ? `\n[Session focus: ${session_type.replace('_', ' ')} guidance]`
      : '';

    const systemWithContext = SYSTEM_PROMPT + contextNote + sessionNote;

    const anthropicMessages = messages.map((m: any) => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    }));

    const response = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 800,
      system: systemWithContext,
      messages: anthropicMessages,
    });

    const responseText = (response.content[0] as any).text;
    return NextResponse.json({ response: responseText });
  } catch (error: any) {
    console.error('Career guidance API error:', error);
    return NextResponse.json({ response: 'I apologize, I\'m having trouble responding right now. Please try again in a moment.' }, { status: 500 });
  }
}
