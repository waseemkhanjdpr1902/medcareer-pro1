import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SECTION_PROMPTS: Record<string, string> = {
  summary: `Enhance this professional summary for a medical CV. Make it:
- Compelling, specific, and results-oriented
- 3-4 sentences (150-350 characters)
- Highlight specialty, key expertise, and career value proposition
- Use active voice and strong verbs
- ATS-friendly with relevant medical keywords
Return only the enhanced summary text, no preamble.`,

  work_experience: `Improve these work experience bullet points for a medical CV:
- Use quantified achievements where possible (e.g., "managed 40+ patients daily")
- Start each bullet with a strong action verb
- Include specific procedures, techniques, or technologies
- Demonstrate impact and leadership
- Keep each point concise but specific
Return the improved description as bullet points with • characters.`,

  skills: `Optimize this list of medical skills for ATS and HR reviewers:
- Add relevant specialty-specific skills that are commonly required
- Include both clinical and administrative skills
- Include relevant certifications, procedures, and equipment
- Organize by category
Return as a simple list with each skill on a new line.`,
};

export async function POST(req: NextRequest) {
  try {
    const { section, current_content, profile_info } = await req.json();

    const basePrompt = SECTION_PROMPTS[section] || `Improve this CV section content for a medical professional. Make it more professional, specific, and ATS-optimized. Return only the improved content.`;

    const contextStr = profile_info
      ? `Context: ${profile_info.specialty || 'Medical'} professional, ${profile_info.designation || ''}, ${profile_info.years || 0} years experience.\n\n`
      : '';

    const contentStr = typeof current_content === 'string'
      ? current_content
      : JSON.stringify(current_content, null, 2);

    const prompt = `${contextStr}${basePrompt}\n\nCurrent content:\n${contentStr}`;

    const message = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 800,
      messages: [{ role: 'user', content: prompt }],
    });

    const enhanced = (message.content[0] as any).text.trim();

    return NextResponse.json({ enhanced });
  } catch (error: any) {
    console.error('CV Builder AI error:', error);
    return NextResponse.json({ error: 'AI enhancement failed.' }, { status: 500 });
  }
}
