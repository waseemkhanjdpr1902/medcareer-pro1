import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { createServiceClient } from '@/lib/supabase-server';
import { getCurrentMonthYear } from '@/lib/utils';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { cv_text, job_role, user_id } = await req.json();

    if (!cv_text || cv_text.trim().length < 100) {
      return NextResponse.json({ error: 'CV content is too short. Please paste your complete CV.' }, { status: 400 });
    }

    const prompt = `You are an expert ATS (Applicant Tracking System) analyzer and medical career coach. Analyze the following CV for a healthcare professional and provide a comprehensive scoring report.

${job_role ? `Target Role: ${job_role}` : 'General medical CV analysis'}

CV CONTENT:
${cv_text}

Provide a detailed JSON analysis with this EXACT structure:
{
  "overall_score": <0-100 integer>,
  "ats_compatibility_score": <0-100>,
  "keyword_score": <0-100>,
  "format_score": <0-100>,
  "content_score": <0-100>,
  "completeness_score": <0-100>,
  "feedback": {
    "strengths": ["strength 1", "strength 2", "strength 3"],
    "weaknesses": ["weakness 1", "weakness 2"],
    "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"]
  },
  "keywords_found": ["keyword1", "keyword2", ...],
  "keywords_missing": ["missing1", "missing2", ...],
  "improvements": [
    "Specific actionable improvement 1",
    "Specific actionable improvement 2",
    "Specific actionable improvement 3",
    "Specific actionable improvement 4",
    "Specific actionable improvement 5"
  ]
}

Scoring criteria:
- ATS Compatibility: proper formatting, no tables/graphics, standard section headings, parseable structure
- Keywords: relevant medical terminology, specialty-specific keywords, required certifications
- Format: chronological order, consistent dates, proper section organization, length (2-4 pages ideal for medical)
- Content: quantified achievements, specific procedures/skills, impact statements, publications/research
- Completeness: all key sections present (summary, education, experience, skills, certifications)

Return ONLY valid JSON, no markdown formatting.`;

    const message = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    });

    const responseText = (message.content[0] as any).text;
    const cleanJson = responseText.replace(/```json\n?|\n?```/g, '').trim();
    const scoreData = JSON.parse(cleanJson);

    // Save to database
    if (user_id) {
      const supabase = createServiceClient();
      await supabase.from('cv_scores').insert({
        user_id,
        overall_score: scoreData.overall_score,
        ats_compatibility_score: scoreData.ats_compatibility_score,
        keyword_score: scoreData.keyword_score,
        format_score: scoreData.format_score,
        content_score: scoreData.content_score,
        completeness_score: scoreData.completeness_score,
        feedback: scoreData.feedback,
        improvements: scoreData.improvements,
        keywords_found: scoreData.keywords_found,
        keywords_missing: scoreData.keywords_missing,
        job_role_targeted: job_role || null,
      });

      // Track usage
      const monthYear = getCurrentMonthYear();
      await supabase.rpc('increment_usage', { p_user_id: user_id, p_feature: 'cv_score', p_month_year: monthYear })
        .catch(() => supabase.from('usage_tracking').upsert({
          user_id, feature: 'cv_score', month_year: monthYear, count: 1
        }, { onConflict: 'user_id,feature,month_year' }));
    }

    return NextResponse.json(scoreData);
  } catch (error: any) {
    console.error('CV Score API error:', error);
    return NextResponse.json({ error: 'Failed to analyze CV. Please try again.' }, { status: 500 });
  }
}
