import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { createServiceClient } from '@/lib/supabase-server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.text();
    const signature = req.headers.get('x-razorpay-signature');

    if (!signature) {
      return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
    }

    // Verify webhook signature
    const expectedSig = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
      .update(body)
      .digest('hex');

    if (expectedSig !== signature) {
      console.error('Webhook signature mismatch');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const event = JSON.parse(body);
    const supabase = createServiceClient();

    console.log('Razorpay webhook event:', event.event);

    switch (event.event) {
      case 'payment.captured': {
        const payment = event.payload.payment.entity;
        const { user_id, plan, billing_cycle } = payment.notes || {};

        if (user_id && plan) {
          const now = new Date();
          const endDate = new Date(now);
          if (billing_cycle === 'yearly') {
            endDate.setFullYear(endDate.getFullYear() + 1);
          } else {
            endDate.setMonth(endDate.getMonth() + 1);
          }

          await supabase.from('profiles').update({
            subscription_tier: plan,
            subscription_status: 'active',
            subscription_start_date: now.toISOString(),
            subscription_end_date: endDate.toISOString(),
          }).eq('id', user_id);

          await supabase.from('subscriptions').upsert({
            user_id,
            razorpay_payment_id: payment.id,
            razorpay_order_id: payment.order_id,
            plan_id: `${plan}_${billing_cycle || 'monthly'}`,
            plan_name: plan,
            billing_cycle: billing_cycle || 'monthly',
            amount: payment.amount,
            currency: payment.currency,
            status: 'active',
            current_period_start: now.toISOString(),
            current_period_end: endDate.toISOString(),
          }, { onConflict: 'razorpay_payment_id' });
        }
        break;
      }

      case 'payment.failed': {
        const payment = event.payload.payment.entity;
        const { user_id } = payment.notes || {};
        if (user_id) {
          await supabase.from('subscriptions').update({ status: 'halted' })
            .eq('razorpay_payment_id', payment.id);
        }
        break;
      }

      case 'subscription.cancelled': {
        const sub = event.payload.subscription.entity;
        if (sub.id) {
          await supabase.from('subscriptions').update({
            status: 'cancelled',
            cancelled_at: new Date().toISOString(),
          }).eq('razorpay_subscription_id', sub.id);

          // Downgrade user to basic at period end
          const { data: dbSub } = await supabase
            .from('subscriptions')
            .select('user_id')
            .eq('razorpay_subscription_id', sub.id)
            .single();

          if (dbSub?.user_id) {
            await supabase.from('profiles').update({
              subscription_status: 'cancelled',
            }).eq('id', dbSub.user_id);
          }
        }
        break;
      }

      case 'subscription.halted': {
        const sub = event.payload.subscription.entity;
        if (sub.id) {
          await supabase.from('subscriptions').update({ status: 'halted' })
            .eq('razorpay_subscription_id', sub.id);
        }
        break;
      }

      default:
        console.log('Unhandled event type:', event.event);
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error);
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}
