import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';
import { PRICING } from '@/lib/utils';

export async function POST(req: NextRequest) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { plan, billing_cycle } = await req.json();

    if (!plan || !billing_cycle) {
      return NextResponse.json({ error: 'Missing plan or billing_cycle' }, { status: 400 });
    }

    const pricing = PRICING[plan as keyof typeof PRICING]?.[billing_cycle as keyof typeof PRICING.professional];
    if (!pricing) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });

    // Create Razorpay order
    const auth = Buffer.from(`${process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');

    const orderRes = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: pricing.amount,
        currency: 'INR',
        receipt: `order_${user.id.slice(0, 8)}_${Date.now()}`,
        notes: {
          user_id: user.id,
          plan,
          billing_cycle,
          user_email: user.email,
        },
      }),
    });

    if (!orderRes.ok) {
      const errData = await orderRes.json();
      throw new Error(errData.error?.description || 'Failed to create order');
    }

    const order = await orderRes.json();

    // Get user profile for prefilling
    const { data: profile } = await supabase.from('profiles').select('full_name, email, phone').eq('id', user.id).single();

    return NextResponse.json({
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
      user: {
        name: profile?.full_name || '',
        email: profile?.email || user.email || '',
        phone: profile?.phone || '',
      },
    });
  } catch (error: any) {
    console.error('Create order error:', error);
    return NextResponse.json({ error: error.message || 'Failed to create order' }, { status: 500 });
  }
}
