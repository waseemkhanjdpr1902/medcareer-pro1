'use client';

import Link from 'next/link';
import { useState } from 'react';
import {
  Activity, BookOpen, BrainCircuit, ChevronRight, CheckCircle2,
  FileText, MessageSquare, Star, TrendingUp, Users, Award,
  Stethoscope, ArrowRight, Play, Shield, Zap, Target, Clock
} from 'lucide-react';

const FEATURES = [
  {
    icon: Activity,
    title: 'CME Credit Tracker',
    description: 'Track all your Continuing Medical Education credits in one place. Get deadline alerts, progress reports, and compliance summaries.',
    color: 'bg-blue-50',
    iconColor: 'text-blue-600',
    tier: 'basic',
  },
  {
    icon: FileText,
    title: 'AI CV Builder',
    description: 'Build a professional medical CV optimized for ATS systems. AI suggests improvements, keywords, and formatting for maximum impact.',
    color: 'bg-teal-50',
    iconColor: 'text-teal-600',
    tier: 'professional',
  },
  {
    icon: Target,
    title: 'ATS Score Checker',
    description: 'Upload your CV and get an instant ATS compatibility score with detailed feedback on keyword density, formatting, and content gaps.',
    color: 'bg-purple-50',
    iconColor: 'text-purple-600',
    tier: 'professional',
  },
  {
    icon: BrainCircuit,
    title: 'AI Career Advisor',
    description: 'Get personalized career guidance from an AI trained on medical career pathways, fellowship opportunities, and specialization trends.',
    color: 'bg-green-50',
    iconColor: 'text-green-600',
    tier: 'professional',
  },
  {
    icon: MessageSquare,
    title: 'Mock Interview Practice',
    description: 'Practice clinical, behavioral, and fellowship interviews with an AI interviewer. Get real-time feedback and performance scores.',
    color: 'bg-orange-50',
    iconColor: 'text-orange-600',
    tier: 'professional',
  },
  {
    icon: TrendingUp,
    title: 'Career Analytics',
    description: 'Visualize your career progression, skill gaps, CME compliance trends, and benchmark against peers in your specialty.',
    color: 'bg-rose-50',
    iconColor: 'text-rose-600',
    tier: 'premium',
  },
];

const PLANS = [
  {
    name: 'Basic',
    price: 'Free',
    period: '',
    description: 'Get started with essential tracking tools',
    color: 'border-gray-200',
    badge: null,
    features: [
      { text: 'CME tracking (up to 10 entries)', included: true },
      { text: '1 CV score check per month', included: true },
      { text: '1 CV template', included: true },
      { text: '3 career guidance sessions', included: true },
      { text: '2 mock interview sessions/month', included: true },
      { text: 'AI CV optimization', included: false },
      { text: 'Advanced analytics', included: false },
      { text: 'PDF export', included: false },
      { text: 'Priority support', included: false },
    ],
    cta: 'Get Started Free',
    ctaVariant: 'outline',
    planKey: 'basic',
  },
  {
    name: 'Professional',
    price: '₹999',
    period: '/month',
    description: 'Everything you need to accelerate your career',
    color: 'border-teal-500',
    badge: 'Most Popular',
    features: [
      { text: 'Unlimited CME tracking', included: true },
      { text: '10 CV score checks per month', included: true },
      { text: '3 CV templates with AI optimization', included: true },
      { text: 'Unlimited career guidance sessions', included: true },
      { text: '15 mock interview sessions/month', included: true },
      { text: 'AI CV optimization & keywords', included: true },
      { text: 'Advanced analytics dashboard', included: true },
      { text: 'PDF export', included: true },
      { text: 'Priority support', included: false },
    ],
    cta: 'Start 7-Day Free Trial',
    ctaVariant: 'primary',
    planKey: 'professional',
  },
  {
    name: 'Premium',
    price: '₹1,999',
    period: '/month',
    description: 'Unlimited access for peak performance',
    color: 'border-gold-500',
    badge: 'Best Value',
    features: [
      { text: 'Everything in Professional', included: true },
      { text: 'Unlimited CV score checks', included: true },
      { text: 'Unlimited CV builders', included: true },
      { text: 'Unlimited mock interviews', included: true },
      { text: 'Advanced specialty-specific prep', included: true },
      { text: 'Fellowship application support', included: true },
      { text: 'Salary benchmarking data', included: true },
      { text: 'Priority 24/7 support', included: true },
      { text: 'Early access to new features', included: true },
    ],
    cta: 'Start 7-Day Free Trial',
    ctaVariant: 'gold',
    planKey: 'premium',
  },
];

const TESTIMONIALS = [
  {
    name: 'Dr. Priya Sharma',
    role: 'Cardiologist, AIIMS Delhi',
    text: 'The AI CV builder helped me land my fellowship at a top institution. My ATS score went from 42% to 91% in just one session.',
    rating: 5,
    avatar: 'PS',
  },
  {
    name: 'Dr. Rahul Mehta',
    role: 'Orthopaedic Surgeon, Manipal',
    text: 'CME tracking used to be a nightmare before renewal. MedCareer Pro makes it effortless with automatic reminders and progress tracking.',
    rating: 5,
    avatar: 'RM',
  },
  {
    name: 'Dr. Anita Krishnan',
    role: 'Paediatric Resident, KEM Hospital',
    text: 'The mock interview feature is incredible. I practiced 20+ sessions before my residency interview and felt completely prepared.',
    rating: 5,
    avatar: 'AK',
  },
];

const STATS = [
  { value: '15,000+', label: 'Healthcare Professionals' },
  { value: '4.8★', label: 'Average Rating' },
  { value: '89%', label: 'Interview Success Rate' },
  { value: '2.3M+', label: 'CME Credits Tracked' },
];

export default function LandingPage() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  return (
    <div className="min-h-screen bg-white font-body">
      {/* NAVBAR */}
      <nav className="fixed top-0 inset-x-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-navy-600 rounded-lg flex items-center justify-center">
                <Stethoscope size={16} className="text-white" />
              </div>
              <span className="font-display text-xl font-bold text-navy-600">MedCareer Pro</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm font-medium text-gray-600 hover:text-navy-600 transition-colors">Features</a>
              <a href="#pricing" className="text-sm font-medium text-gray-600 hover:text-navy-600 transition-colors">Pricing</a>
              <a href="#testimonials" className="text-sm font-medium text-gray-600 hover:text-navy-600 transition-colors">Testimonials</a>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/auth/login" className="text-sm font-semibold text-gray-700 hover:text-navy-600 transition-colors px-4 py-2">
                Log in
              </Link>
              <Link href="/auth/signup" className="btn-primary text-sm">
                Get Started Free
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="pt-32 pb-20 bg-hero-mesh relative overflow-hidden">
        <div className="absolute inset-0 bg-navy-900/80" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white/90 rounded-full px-4 py-1.5 text-sm font-medium mb-8 border border-white/20">
            <Zap size={14} className="text-gold-400" />
            AI-Powered Career Platform for Healthcare Professionals
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Elevate Your<br />
            <span className="text-teal-400">Medical Career</span>
          </h1>
          <p className="text-xl text-white/80 mb-10 max-w-2xl mx-auto leading-relaxed">
            Track CME credits, build ATS-optimized CVs, get AI career guidance, and ace your interviews — all in one platform built for healthcare professionals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup" className="inline-flex items-center justify-center gap-2 bg-white text-navy-600 px-8 py-4 rounded-xl font-bold text-base hover:bg-gray-50 transition-all shadow-lg hover:shadow-xl">
              Start for Free
              <ArrowRight size={18} />
            </Link>
            <button className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-4 rounded-xl font-bold text-base hover:bg-white/20 transition-all">
              <Play size={16} className="fill-current" />
              Watch Demo
            </button>
          </div>
          <p className="mt-6 text-white/60 text-sm">No credit card required · Free plan always available</p>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
            {STATS.map(stat => (
              <div key={stat.label} className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
                <div className="font-display text-3xl font-bold text-white">{stat.value}</div>
                <div className="text-white/70 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-24 bg-medical-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-heading mb-4">Everything You Need to Succeed</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Purpose-built tools for every stage of your medical career journey.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feature) => (
              <div key={feature.title} className="card-hover group">
                <div className={`${feature.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon size={22} className={feature.iconColor} />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold text-gray-900 text-lg">{feature.title}</h3>
                  <span className={`badge ${feature.tier === 'basic' ? 'badge-basic' : feature.tier === 'professional' ? 'badge-professional' : 'badge-premium'}`}>
                    {feature.tier === 'basic' ? 'Free' : feature.tier === 'professional' ? 'Pro' : 'Premium'}
                  </span>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-heading mb-4">Get Started in Minutes</h2>
            <p className="text-gray-600 text-lg">Three simple steps to transform your career trajectory.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', icon: Users, title: 'Create Your Profile', desc: 'Sign up and tell us about your specialty, experience, and career goals.' },
              { step: '02', icon: FileText, title: 'Build Your Portfolio', desc: 'Import your existing CV or build fresh. Track your CME credits and achievements.' },
              { step: '03', icon: TrendingUp, title: 'Accelerate Growth', desc: 'Use AI tools for career guidance, interview prep, and CV optimization.' },
            ].map((step) => (
              <div key={step.step} className="text-center relative">
                <div className="w-16 h-16 bg-navy-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-glow-navy">
                  <step.icon size={28} className="text-white" />
                </div>
                <div className="font-display text-6xl font-bold text-gray-100 absolute -top-4 left-1/2 -translate-x-1/2 -z-10">{step.step}</div>
                <h3 className="font-semibold text-xl text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-24 bg-medical-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-heading mb-4">Simple, Transparent Pricing</h2>
            <p className="text-gray-600 text-lg mb-8">Choose the plan that fits your career stage.</p>
            <div className="inline-flex bg-white rounded-xl p-1 border border-gray-200 shadow-sm">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${billingCycle === 'monthly' ? 'bg-navy-600 text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${billingCycle === 'yearly' ? 'bg-navy-600 text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
              >
                Yearly
                <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full">Save 17%</span>
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {PLANS.map((plan) => (
              <div key={plan.name} className={`bg-white rounded-2xl border-2 ${plan.color} p-8 relative shadow-card ${plan.name === 'Professional' ? 'shadow-glow-teal scale-105' : ''}`}>
                {plan.badge && (
                  <div className={`absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold text-white ${plan.name === 'Professional' ? 'bg-teal-500' : 'bg-gold-500'}`}>
                    {plan.badge}
                  </div>
                )}
                <div className="mb-6">
                  <h3 className="font-display text-2xl font-bold text-gray-900">{plan.name}</h3>
                  <p className="text-gray-500 text-sm mt-1">{plan.description}</p>
                </div>
                <div className="mb-6">
                  <span className="font-display text-4xl font-bold text-gray-900">
                    {plan.price === 'Free' ? plan.price : (
                      billingCycle === 'yearly' && plan.planKey !== 'basic'
                        ? (plan.planKey === 'professional' ? '₹833' : '₹1,666')
                        : plan.price
                    )}
                  </span>
                  {plan.period && (
                    <span className="text-gray-500 text-sm">{billingCycle === 'yearly' ? '/month, billed yearly' : plan.period}</span>
                  )}
                </div>
                <Link
                  href={plan.planKey === 'basic' ? '/auth/signup' : `/auth/signup?plan=${plan.planKey}&billing=${billingCycle}`}
                  className={`block w-full text-center py-3 rounded-xl font-bold text-sm mb-8 transition-all ${
                    plan.ctaVariant === 'primary' ? 'bg-teal-500 text-white hover:bg-teal-600'
                    : plan.ctaVariant === 'gold' ? 'bg-gold-500 text-white hover:bg-gold-600'
                    : 'border-2 border-gray-300 text-gray-700 hover:border-navy-600 hover:text-navy-600'
                  }`}
                >
                  {plan.cta}
                </Link>
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature.text} className="flex items-start gap-3">
                      <CheckCircle2
                        size={16}
                        className={`flex-shrink-0 mt-0.5 ${feature.included ? 'text-teal-500' : 'text-gray-300'}`}
                        strokeWidth={feature.included ? 2.5 : 2}
                      />
                      <span className={`text-sm ${feature.included ? 'text-gray-700' : 'text-gray-400'}`}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-heading mb-4">Trusted by Healthcare Professionals</h2>
            <p className="text-gray-600 text-lg">See what doctors, residents, and specialists are saying.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="card-hover">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={16} className="fill-gold-400 text-gold-400" />
                  ))}
                </div>
                <p className="text-gray-700 leading-relaxed mb-6">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-navy-600 flex items-center justify-center text-white font-bold text-sm">
                    {t.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                    <div className="text-gray-500 text-xs">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="py-24 bg-navy-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-teal-400 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-gold-400 rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Transform Your Medical Career?
          </h2>
          <p className="text-white/80 text-xl mb-10">
            Join 15,000+ healthcare professionals who are advancing their careers with MedCareer Pro.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup" className="inline-flex items-center justify-center gap-2 bg-white text-navy-600 px-8 py-4 rounded-xl font-bold text-base hover:bg-gray-50 transition-all shadow-lg">
              Get Started Free Today
              <ChevronRight size={18} />
            </Link>
          </div>
          <div className="mt-8 flex items-center justify-center gap-8 text-white/60 text-sm">
            <div className="flex items-center gap-2"><Shield size={14} /> HIPAA Compliant</div>
            <div className="flex items-center gap-2"><Clock size={14} /> Setup in 2 minutes</div>
            <div className="flex items-center gap-2"><Award size={14} /> No credit card required</div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-gray-900 text-gray-400 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center">
                  <Stethoscope size={16} className="text-white" />
                </div>
                <span className="font-display text-xl font-bold text-white">MedCareer Pro</span>
              </div>
              <p className="text-sm leading-relaxed">The complete career management platform built exclusively for healthcare professionals.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><Link href="/auth/signup" className="hover:text-white transition-colors">Get Started</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cookie Policy</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="mailto:support@medcareerpro.in" className="hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm">© 2025 MedCareer Pro. All rights reserved.</p>
            <p className="text-sm">Made with ❤️ for Healthcare Professionals in India</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
