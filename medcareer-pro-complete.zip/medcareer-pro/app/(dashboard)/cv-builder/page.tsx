'use client';

import { useEffect, useState } from 'react';
import { Plus, Trash2, Loader2, Save, Wand2, Lock, Download, CheckCircle2 } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';

const SECTIONS: Record<string, string> = {
  personal_info: 'Personal Information',
  summary: 'Professional Summary',
  work_experience: 'Work Experience',
  education: 'Education',
  skills: 'Skills',
  publications: 'Publications',
  certifications: 'Certifications & Licences',
  awards: 'Awards & Honours',
  research: 'Research',
  professional_memberships: 'Memberships',
  languages: 'Languages',
};

export default function CvBuilderPage() {
  const [profile, setProfile] = useState<any>(null);
  const [cvData, setCvData] = useState<any>(null);
  const [cvId, setCvId] = useState<string | null>(null);
  const [active, setActive] = useState('personal_info');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [aiLoading, setAiLoading] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [userId, setUserId] = useState('');

  const blank: any = {
    personal_info: { full_name: '', email: '', phone: '', address: '', linkedin: '', website: '' },
    summary: '',
    work_experience: [], education: [], skills: [], publications: [],
    certifications: [], awards: [], research: [], professional_memberships: [], languages: [],
  };

  useEffect(() => {
    (async () => {
      const sb = getSupabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const [pr, cv] = await Promise.all([
        sb.from('profiles').select('*').eq('id', user.id).single(),
        sb.from('cv_data').select('*').eq('user_id', user.id).eq('is_primary', true).maybeSingle(),
      ]);
      setProfile(pr.data);
      if (cv.data) {
        setCvId(cv.data.id);
        const merged: any = {};
        Object.keys(blank).forEach(k => { merged[k] = cv.data[k] ?? blank[k]; });
        setCvData(merged);
      } else {
        setCvData({ ...blank, personal_info: { ...blank.personal_info, full_name: pr.data?.full_name || '', email: pr.data?.email || '', linkedin: pr.data?.linkedin_url || '' } });
      }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    const sb = getSupabase();
    const payload: any = { user_id: userId, is_primary: true, cv_name: 'Primary CV', summary: cvData.summary, personal_info: cvData.personal_info };
    Object.keys(blank).filter(k => k !== 'summary' && k !== 'personal_info').forEach(k => { payload[k] = cvData[k]; });
    if (cvId) { await sb.from('cv_data').update(payload).eq('id', cvId); }
    else { const { data } = await sb.from('cv_data').insert(payload).select().single(); if (data) setCvId(data.id); }
    setSaving(false); setSaved(true); setTimeout(() => setSaved(false), 2500);
  };

  const aiEnhance = async (section: string) => {
    if (profile?.subscription_tier === 'basic') return;
    setAiLoading(section);
    try {
      const r = await fetch('/api/ai/cv-builder', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ section, current_content: cvData[section], profile_info: { specialty: profile?.specialty, designation: profile?.designation, years: profile?.years_of_experience } }) });
      const d = await r.json();
      if (d.enhanced) setCvData((p: any) => ({ ...p, [section]: d.enhanced }));
    } catch {}
    setAiLoading(null);
  };

  const exportPdf = async () => {
    await save();
    setExporting(true);
    try {
      const r = await fetch('/api/cv-export', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cv_id: cvId }) });
      if (!r.ok) { alert((await r.json()).error || 'Export failed'); setExporting(false); return; }
      const html = await r.text();
      const w = window.open('', '_blank');
      if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 600); }
    } catch (e: any) { alert(e.message); }
    setExporting(false);
  };

  const addItem = (sec: string, tmpl: any) => setCvData((p: any) => ({ ...p, [sec]: [...(p[sec] || []), { ...tmpl, id: Date.now().toString() }] }));
  const removeItem = (sec: string, id: string) => setCvData((p: any) => ({ ...p, [sec]: p[sec].filter((i: any) => i.id !== id) }));
  const updateItem = (sec: string, id: string, field: string, val: string) => setCvData((p: any) => ({ ...p, [sec]: p[sec].map((i: any) => i.id === id ? { ...i, [field]: val } : i) }));
  const setPI = (field: string, val: string) => setCvData((p: any) => ({ ...p, personal_info: { ...p.personal_info, [field]: val } }));

  const isLocked = (sec: string) => profile?.subscription_tier === 'basic' && ['publications', 'research'].includes(sec);
  const canExport = profile?.subscription_tier !== 'basic';

  if (!cvData) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-teal-500" size={32} /></div>;

  const renderSection = () => {
    if (active === 'personal_info') return (
      <div className="grid grid-cols-2 gap-4">
        {([['full_name','Full Name','Dr. Jane Smith','col-span-2'],['email','Email','doctor@hospital.com',''],['phone','Phone','+91 98765 43210',''],['address','Location','Mumbai, India','col-span-2'],['linkedin','LinkedIn URL','linkedin.com/in/drjane',''],['website','Website / ORCID','orcid.org/...','']]) as [string,string,string,string][]).map(([f,l,ph,cls]) => (
          <div key={f} className={cls}>
            <label className="label">{l}</label>
            <input value={cvData.personal_info[f]||''} onChange={e=>setPI(f,e.target.value)} className="input-field" placeholder={ph}/>
          </div>
        ))}
      </div>
    );

    if (active === 'summary') return (
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="label">Professional Summary</label>
          {profile?.subscription_tier !== 'basic' && (
            <button onClick={()=>aiEnhance('summary')} disabled={aiLoading==='summary'} className="flex items-center gap-1.5 text-xs font-semibold text-teal-600 px-3 py-1 bg-teal-50 rounded-lg hover:bg-teal-100 transition-colors">
              {aiLoading==='summary'?<Loader2 size={12} className="animate-spin"/>:<Wand2 size={12}/>} AI Enhance
            </button>
          )}
        </div>
        <textarea value={cvData.summary||''} onChange={e=>setCvData((p:any)=>({...p,summary:e.target.value}))} className="input-field min-h-[180px] resize-none" placeholder="3–4 sentence compelling summary of your clinical expertise, achievements, and career goals..."/>
        <p className="text-xs text-gray-400 mt-1">{cvData.summary?.length||0} chars</p>
      </div>
    );

    if (active === 'work_experience') return (
      <div className="space-y-4">
        {(cvData.work_experience||[]).map((e:any)=>(
          <div key={e.id} className="border border-gray-200 rounded-xl p-4 space-y-3 relative">
            <button onClick={()=>removeItem('work_experience',e.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"><Trash2 size={14}/></button>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><label className="label">Position *</label><input value={e.position||''} onChange={ev=>updateItem('work_experience',e.id,'position',ev.target.value)} className="input-field" placeholder="Senior Resident / Consultant Cardiologist"/></div>
              <div><label className="label">Department</label><input value={e.department||''} onChange={ev=>updateItem('work_experience',e.id,'department',ev.target.value)} className="input-field" placeholder="Cardiology"/></div>
              <div><label className="label">Institution *</label><input value={e.institution||''} onChange={ev=>updateItem('work_experience',e.id,'institution',ev.target.value)} className="input-field" placeholder="AIIMS, New Delhi"/></div>
              <div><label className="label">Start</label><input type="month" value={e.start_date||''} onChange={ev=>updateItem('work_experience',e.id,'start_date',ev.target.value)} className="input-field"/></div>
              <div><label className="label">End</label><input type="month" value={e.end_date||''} onChange={ev=>updateItem('work_experience',e.id,'end_date',ev.target.value)} className="input-field" placeholder="Present"/></div>
              <div className="col-span-2"><label className="label">Responsibilities & Achievements</label><textarea value={e.description||''} onChange={ev=>updateItem('work_experience',e.id,'description',ev.target.value)} className="input-field min-h-[90px] resize-none text-sm" placeholder="• Managed 30+ ICU patients daily&#10;• Led junior resident teaching rounds&#10;• Performed 200+ coronary angiographies"/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('work_experience',{position:'',department:'',institution:'',start_date:'',end_date:'',description:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Position</button>
      </div>
    );

    if (active === 'education') return (
      <div className="space-y-4">
        {(cvData.education||[]).map((e:any)=>(
          <div key={e.id} className="border border-gray-200 rounded-xl p-4 relative">
            <button onClick={()=>removeItem('education',e.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Degree *</label><input value={e.degree||''} onChange={ev=>updateItem('education',e.id,'degree',ev.target.value)} className="input-field" placeholder="MBBS / MD / DM / DNB"/></div>
              <div><label className="label">Specialization</label><input value={e.specialization||''} onChange={ev=>updateItem('education',e.id,'specialization',ev.target.value)} className="input-field" placeholder="Cardiology"/></div>
              <div className="col-span-2"><label className="label">Institution *</label><input value={e.institution||''} onChange={ev=>updateItem('education',e.id,'institution',ev.target.value)} className="input-field" placeholder="AIIMS New Delhi"/></div>
              <div><label className="label">Year</label><input type="number" min={1970} max={2030} value={e.year||''} onChange={ev=>updateItem('education',e.id,'year',ev.target.value)} className="input-field" placeholder="2020"/></div>
              <div><label className="label">Score / Rank</label><input value={e.score||''} onChange={ev=>updateItem('education',e.id,'score',ev.target.value)} className="input-field" placeholder="75% / Gold Medalist / NEET Rank 45"/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('education',{degree:'',specialization:'',institution:'',year:'',score:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Education</button>
      </div>
    );

    if (active === 'skills') return (
      <div className="space-y-3">
        {(cvData.skills||[]).map((s:any)=>(
          <div key={s.id} className="flex items-center gap-3">
            <input value={s.name||''} onChange={e=>updateItem('skills',s.id,'name',e.target.value)} className="input-field flex-1" placeholder="Coronary Angiography, ACLS, POCUS, Echocardiography"/>
            <select value={s.level||'Expert'} onChange={e=>updateItem('skills',s.id,'level',e.target.value)} className="input-field w-36">
              {['Beginner','Intermediate','Advanced','Expert'].map(l=><option key={l}>{l}</option>)}
            </select>
            <button onClick={()=>removeItem('skills',s.id)} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded flex-shrink-0"><Trash2 size={14}/></button>
          </div>
        ))}
        <button onClick={()=>addItem('skills',{name:'',level:'Expert'})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Skill</button>
      </div>
    );

    if (active === 'publications') return (
      <div className="space-y-4">
        {(cvData.publications||[]).map((pub:any)=>(
          <div key={pub.id} className="border border-gray-200 rounded-xl p-4 relative">
            <button onClick={()=>removeItem('publications',pub.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><label className="label">Article Title *</label><input value={pub.title||''} onChange={e=>updateItem('publications',pub.id,'title',e.target.value)} className="input-field" placeholder="Full article title"/></div>
              <div><label className="label">Journal *</label><input value={pub.journal||''} onChange={e=>updateItem('publications',pub.id,'journal',e.target.value)} className="input-field" placeholder="Indian Heart Journal"/></div>
              <div><label className="label">Year</label><input type="number" value={pub.year||''} onChange={e=>updateItem('publications',pub.id,'year',e.target.value)} className="input-field" placeholder="2023"/></div>
              <div><label className="label">Authors</label><input value={pub.authors||''} onChange={e=>updateItem('publications',pub.id,'authors',e.target.value)} className="input-field" placeholder="Smith J, Doe A, et al."/></div>
              <div><label className="label">DOI / PMID</label><input value={pub.doi||''} onChange={e=>updateItem('publications',pub.id,'doi',e.target.value)} className="input-field" placeholder="10.xxxx/..."/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('publications',{title:'',journal:'',year:'',authors:'',doi:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Publication</button>
      </div>
    );

    if (active === 'certifications') return (
      <div className="space-y-4">
        {(cvData.certifications||[]).map((c:any)=>(
          <div key={c.id} className="border border-gray-200 rounded-xl p-4 relative">
            <button onClick={()=>removeItem('certifications',c.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><label className="label">Name *</label><input value={c.name||''} onChange={e=>updateItem('certifications',c.id,'name',e.target.value)} className="input-field" placeholder="DNB, MRCP, USMLE Step 1"/></div>
              <div><label className="label">Issuing Body</label><input value={c.issuer||''} onChange={e=>updateItem('certifications',c.id,'issuer',e.target.value)} className="input-field" placeholder="NMC, RCPCH"/></div>
              <div><label className="label">Year</label><input type="number" value={c.year||''} onChange={e=>updateItem('certifications',c.id,'year',e.target.value)} className="input-field" placeholder="2022"/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('certifications',{name:'',issuer:'',year:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Certification</button>
      </div>
    );

    if (active === 'awards') return (
      <div className="space-y-4">
        {(cvData.awards||[]).map((a:any)=>(
          <div key={a.id} className="border border-gray-200 rounded-xl p-4 relative">
            <button onClick={()=>removeItem('awards',a.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><label className="label">Award / Honour *</label><input value={a.title||''} onChange={e=>updateItem('awards',a.id,'title',e.target.value)} className="input-field" placeholder="Best Research Paper Award 2023"/></div>
              <div><label className="label">Organisation</label><input value={a.organization||''} onChange={e=>updateItem('awards',a.id,'organization',e.target.value)} className="input-field" placeholder="IMA, CSI, AIIMS"/></div>
              <div><label className="label">Year</label><input type="number" value={a.year||''} onChange={e=>updateItem('awards',a.id,'year',e.target.value)} className="input-field" placeholder="2023"/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('awards',{title:'',organization:'',year:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Award</button>
      </div>
    );

    if (active === 'languages') return (
      <div className="space-y-3">
        {(cvData.languages||[]).map((l:any)=>(
          <div key={l.id} className="flex items-center gap-3">
            <input value={l.name||''} onChange={e=>updateItem('languages',l.id,'name',e.target.value)} className="input-field flex-1" placeholder="Hindi, English, Tamil…"/>
            <select value={l.proficiency||'Fluent'} onChange={e=>updateItem('languages',l.id,'proficiency',e.target.value)} className="input-field w-40">
              {['Native','Fluent','Professional','Conversational','Basic'].map(p=><option key={p}>{p}</option>)}
            </select>
            <button onClick={()=>removeItem('languages',l.id)} className="p-1.5 text-red-400 hover:text-red-600 rounded flex-shrink-0"><Trash2 size={14}/></button>
          </div>
        ))}
        <button onClick={()=>addItem('languages',{name:'',proficiency:'Fluent'})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Language</button>
      </div>
    );

    if (active === 'professional_memberships') return (
      <div className="space-y-3">
        {(cvData.professional_memberships||[]).map((m:any)=>(
          <div key={m.id} className="flex items-center gap-3">
            <input value={m.name||''} onChange={e=>updateItem('professional_memberships',m.id,'name',e.target.value)} className="input-field flex-1" placeholder="Indian Medical Association (IMA)"/>
            <input type="number" value={m.year||''} onChange={e=>updateItem('professional_memberships',m.id,'year',e.target.value)} className="input-field w-24" placeholder="Year"/>
            <button onClick={()=>removeItem('professional_memberships',m.id)} className="p-1.5 text-red-400 hover:text-red-600 rounded flex-shrink-0"><Trash2 size={14}/></button>
          </div>
        ))}
        <button onClick={()=>addItem('professional_memberships',{name:'',year:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Membership</button>
      </div>
    );

    if (active === 'research') return (
      <div className="space-y-4">
        {(cvData.research||[]).map((r:any)=>(
          <div key={r.id} className="border border-gray-200 rounded-xl p-4 relative">
            <button onClick={()=>removeItem('research',r.id)} className="absolute top-3 right-3 p-1 text-red-400 hover:text-red-600 rounded"><Trash2 size={14}/></button>
            <div className="space-y-3">
              <div><label className="label">Research Title *</label><input value={r.title||''} onChange={e=>updateItem('research',r.id,'title',e.target.value)} className="input-field" placeholder="Study title or project name"/></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Role</label><input value={r.role||''} onChange={e=>updateItem('research',r.id,'role',e.target.value)} className="input-field" placeholder="Principal Investigator"/></div>
                <div><label className="label">Institution</label><input value={r.institution||''} onChange={e=>updateItem('research',r.id,'institution',e.target.value)} className="input-field" placeholder="AIIMS New Delhi"/></div>
                <div><label className="label">Year</label><input type="number" value={r.year||''} onChange={e=>updateItem('research',r.id,'year',e.target.value)} className="input-field" placeholder="2023"/></div>
              </div>
              <div><label className="label">Description</label><textarea value={r.description||''} onChange={e=>updateItem('research',r.id,'description',e.target.value)} className="input-field min-h-[80px] resize-none text-sm" placeholder="Brief overview of the study, methodology, and findings…"/></div>
            </div>
          </div>
        ))}
        <button onClick={()=>addItem('research',{title:'',role:'',institution:'',year:'',description:''})} className="btn-secondary w-full py-2.5 flex items-center justify-center gap-2 text-sm"><Plus size={14}/> Add Research</button>
      </div>
    );

    return null;
  };

  return (
    <div className="animate-fade-up">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">CV Builder</h1>
          <p className="text-gray-500 text-sm mt-1">Build a professional, ATS-optimised medical CV</p>
        </div>
        <div className="flex items-center gap-2">
          {saved && <span className="text-sm text-green-600 font-medium flex items-center gap-1.5"><CheckCircle2 size={14}/> Saved!</span>}
          {canExport && (
            <button onClick={exportPdf} disabled={exporting} className="btn-secondary flex items-center gap-2 text-sm py-2 px-4">
              {exporting ? <Loader2 size={14} className="animate-spin"/> : <Download size={14}/>}
              {exporting ? 'Generating…' : 'Export PDF'}
            </button>
          )}
          <button onClick={save} disabled={saving} className="btn-primary flex items-center gap-2 text-sm py-2 px-5">
            {saving ? <Loader2 size={14} className="animate-spin"/> : <Save size={14}/>}
            {saving ? 'Saving…' : 'Save'}
          </button>
        </div>
      </div>

      <div className="flex gap-5" style={{height:'calc(100vh - 200px)'}}>
        <div className="w-52 flex-shrink-0 overflow-y-auto">
          <div className="card p-2 space-y-0.5 h-full">
            {Object.entries(SECTIONS).map(([key, label]) => (
              <button key={key} onClick={()=>setActive(key)}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-medium transition-all flex items-center justify-between gap-2 ${active===key?'bg-navy-600 text-white shadow-sm':'text-gray-600 hover:bg-gray-100'} ${isLocked(key)?'opacity-50':''}`}>
                <span className="truncate">{label}</span>
                {isLocked(key)&&<Lock size={11} className="flex-shrink-0"/>}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 card overflow-y-auto">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-semibold text-gray-900 text-lg">{SECTIONS[active]}</h2>
            {active==='summary'&&profile?.subscription_tier==='basic'&&(
              <span className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full flex items-center gap-1.5"><Lock size={10}/> AI Enhance — Pro only</span>
            )}
          </div>
          {isLocked(active)?(
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <Lock size={40} className="text-gray-200 mb-4"/>
              <p className="font-semibold text-gray-900">Professional Feature</p>
              <p className="text-gray-400 text-sm mt-1 max-w-xs">Upgrade to add {SECTIONS[active]}.</p>
              <a href="/pricing" className="btn-teal mt-4 text-sm py-2 px-5 inline-block">Upgrade Plan</a>
            </div>
          ):renderSection()}
        </div>
      </div>
    </div>
  );
}
