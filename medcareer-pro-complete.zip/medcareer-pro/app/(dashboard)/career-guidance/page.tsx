'use client';

import { useEffect, useState, useRef } from 'react';
import { BrainCircuit, Send, Plus, Loader2, Lock, MessageSquare, Sparkles, Trash2 } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';

interface Message { role: 'user' | 'assistant'; content: string; }

const SESSION_TYPES = [
  { value: 'general', label: '🧭 General Career', desc: 'Broad career questions and planning' },
  { value: 'career_planning', label: '📈 Career Planning', desc: 'Long-term roadmap and goal setting' },
  { value: 'specialization', label: '🔬 Specialization Advice', desc: 'Choosing or switching specialty' },
  { value: 'fellowship', label: '🎓 Fellowship', desc: 'Fellowship applications and guidance' },
  { value: 'job_search', label: '💼 Job Search', desc: 'Job hunting strategies and tips' },
  { value: 'salary_negotiation', label: '💰 Salary Negotiation', desc: 'Compensation negotiation strategies' },
  { value: 'research', label: '🔭 Research Career', desc: 'Academic and research pathway' },
];

const STARTER_PROMPTS = [
  "What's the best path to become a cardiologist interventionist in India?",
  "How do I prepare for a fellowship application at top US hospitals?",
  "What skills should I develop as a surgical resident to become more competitive?",
  "How should I negotiate my first consultant salary?",
  "What's the difference between MD and DNB, and which should I pursue?",
  "How can I transition from clinical medicine to healthcare administration?",
];

export default function CareerGuidancePage() {
  const [profile, setProfile] = useState<any>(null);
  const [sessions, setSessions] = useState<any[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sessionType, setSessionType] = useState('general');
  const [userId, setUserId] = useState('');
  const [totalSessions, setTotalSessions] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const [profileRes, sessionsRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('career_sessions').select('id, session_title, session_type, created_at').eq('user_id', user.id).order('updated_at', { ascending: false }).limit(20),
      ]);
      setProfile(profileRes.data);
      setSessions(sessionsRes.data || []);
      setTotalSessions(sessionsRes.data?.length || 0);
    };
    load();
  }, []);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const getLimit = () => {
    if (!profile) return 3;
    if (profile.subscription_tier === 'premium' || profile.subscription_tier === 'professional') return Infinity;
    return 3;
  };

  const canChat = totalSessions < getLimit() || activeSessionId !== null;

  const loadSession = async (sessionId: string) => {
    const supabase = getSupabase();
    const { data } = await supabase.from('career_sessions').select('messages, session_type').eq('id', sessionId).single();
    if (data) {
      setMessages(data.messages || []);
      setSessionType(data.session_type || 'general');
      setActiveSessionId(sessionId);
    }
  };

  const startNewSession = async () => {
    if (totalSessions >= getLimit()) return;
    const supabase = getSupabase();
    const { data } = await supabase.from('career_sessions').insert({
      user_id: userId,
      session_type: sessionType,
      session_title: `${SESSION_TYPES.find(t => t.value === sessionType)?.label || 'Career'} Session`,
      messages: [],
    }).select().single();
    if (data) {
      setActiveSessionId(data.id);
      setSessions(p => [data, ...p]);
      setTotalSessions(p => p + 1);
      setMessages([]);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    if (!activeSessionId) { await startNewSession(); }

    const userMsg: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/career-guidance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          profile_context: { specialty: profile?.specialty, designation: profile?.designation, years: profile?.years_of_experience },
          session_type: sessionType,
        }),
      });
      const data = await res.json();
      const assistantMsg: Message = { role: 'assistant', content: data.response || 'Sorry, I could not process your request.' };
      const finalMessages = [...newMessages, assistantMsg];
      setMessages(finalMessages);

      const supabase = getSupabase();
      const currentSessionId = activeSessionId;
      if (currentSessionId) {
        await supabase.from('career_sessions').update({ messages: finalMessages, updated_at: new Date().toISOString() }).eq('id', currentSessionId);
      }
    } catch {
      setMessages(p => [...p, { role: 'assistant', content: 'Something went wrong. Please try again.' }]);
    }
    setLoading(false);
  };

  const handleDeleteSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const supabase = getSupabase();
    await supabase.from('career_sessions').delete().eq('id', id);
    setSessions(p => p.filter(s => s.id !== id));
    setTotalSessions(p => p - 1);
    if (activeSessionId === id) { setActiveSessionId(null); setMessages([]); }
  };

  return (
    <div className="animate-fade-up h-[calc(100vh-120px)] flex gap-6">
      {/* Sessions sidebar */}
      <div className="w-64 flex-shrink-0 flex flex-col gap-3">
        <div className="card p-3">
          <button
            onClick={startNewSession}
            disabled={totalSessions >= getLimit() || loading}
            className="w-full btn-teal py-2.5 text-sm flex items-center justify-center gap-2"
          >
            <Plus size={16} /> New Session
          </button>
          <div className="mt-3">
            <label className="label text-xs">Session Type</label>
            <select value={sessionType} onChange={e => setSessionType(e.target.value)} className="input-field text-xs py-1.5">
              {SESSION_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          {profile?.subscription_tier === 'basic' && (
            <div className="mt-3 text-center">
              <p className="text-xs text-gray-500">{totalSessions} / 3 sessions used</p>
              {totalSessions >= 3 && (
                <a href="/pricing" className="text-xs text-teal-600 font-semibold">Upgrade for unlimited →</a>
              )}
            </div>
          )}
        </div>

        <div className="card p-3 flex-1 overflow-y-auto">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Recent Sessions</h3>
          {sessions.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-4">No sessions yet</p>
          ) : (
            <ul className="space-y-1">
              {sessions.map(s => (
                <li key={s.id}>
                  <button
                    onClick={() => loadSession(s.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all flex items-start justify-between group ${activeSessionId === s.id ? 'bg-navy-600 text-white' : 'hover:bg-gray-100 text-gray-600'}`}
                  >
                    <span className="truncate flex-1">{s.session_title}</span>
                    <button onClick={(e) => handleDeleteSession(s.id, e)} className={`opacity-0 group-hover:opacity-100 p-0.5 rounded hover:text-red-400 ml-1 flex-shrink-0 ${activeSessionId === s.id ? 'text-white/60 hover:text-white' : ''}`}>
                      <Trash2 size={10} />
                    </button>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 card flex flex-col min-h-0 p-0 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
          <div className="w-9 h-9 bg-gradient-to-br from-green-500 to-teal-500 rounded-xl flex items-center justify-center">
            <BrainCircuit size={18} className="text-white" />
          </div>
          <div>
            <p className="font-semibold text-gray-900 text-sm">AI Career Advisor</p>
            <p className="text-xs text-gray-400">{SESSION_TYPES.find(t => t.value === sessionType)?.desc || 'Healthcare career specialist'}</p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse-soft" />
            <span className="text-xs text-gray-400">Online</span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-8 text-center">
              <Sparkles size={40} className="text-gray-200 mb-4" />
              <h3 className="font-semibold text-gray-900 text-lg mb-2">Your AI Career Advisor</h3>
              <p className="text-gray-400 text-sm max-w-sm mb-8">Ask me anything about your medical career — specialization choices, fellowship applications, job transitions, or career planning.</p>
              <div className="grid grid-cols-1 gap-2 w-full max-w-md">
                {STARTER_PROMPTS.slice(0, 4).map(prompt => (
                  <button
                    key={prompt}
                    onClick={() => { setInput(prompt); }}
                    className="text-left text-sm text-gray-600 bg-gray-50 hover:bg-teal-50 hover:text-teal-700 border border-gray-200 hover:border-teal-200 rounded-xl px-4 py-2.5 transition-all"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'assistant' && (
                  <div className="w-7 h-7 bg-gradient-to-br from-green-500 to-teal-500 rounded-lg flex items-center justify-center flex-shrink-0 mr-2 mt-0.5">
                    <BrainCircuit size={14} className="text-white" />
                  </div>
                )}
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${msg.role === 'user' ? 'chat-bubble-user rounded-br-sm' : 'chat-bubble-ai rounded-bl-sm text-gray-800'}`}>
                  {msg.content.split('\n').map((line, j) => (
                    <p key={j} className={j > 0 ? 'mt-2' : ''}>{line}</p>
                  ))}
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="flex justify-start">
              <div className="w-7 h-7 bg-gradient-to-br from-green-500 to-teal-500 rounded-lg flex items-center justify-center mr-2 mt-0.5">
                <BrainCircuit size={14} className="text-white" />
              </div>
              <div className="chat-bubble-ai rounded-2xl rounded-bl-sm px-4 py-3">
                <div className="flex gap-1.5 items-center h-5">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-1.5 h-1.5 bg-gray-400 rounded-full typing-dot" style={{ animationDelay: `${i * 0.2}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        {!canChat ? (
          <div className="p-4 border-t border-gray-100 bg-amber-50 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-amber-700">
              <Lock size={14} />
              <span>Free session limit reached. Upgrade to continue chatting.</span>
            </div>
            <a href="/pricing" className="btn-teal text-xs py-2 px-4">Upgrade</a>
          </div>
        ) : (
          <div className="p-4 border-t border-gray-100 flex-shrink-0">
            <div className="flex items-end gap-3">
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                className="flex-1 input-field resize-none min-h-[44px] max-h-[120px] py-3"
                placeholder="Ask about career paths, fellowship applications, job transitions..."
                rows={1}
              />
              <button
                onClick={handleSend}
                disabled={loading || !input.trim()}
                className="btn-teal p-3 rounded-xl flex-shrink-0"
              >
                {loading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-2">Press Enter to send · Shift+Enter for new line</p>
          </div>
        )}
      </div>
    </div>
  );
}
