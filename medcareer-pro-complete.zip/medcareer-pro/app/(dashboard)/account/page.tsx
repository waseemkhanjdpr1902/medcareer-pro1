'use client';

import { useEffect, useState } from 'react';
import { User, CreditCard, Bell, Shield, Save, Loader2, CheckCircle2 } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { MEDICAL_SPECIALTIES, SUBSCRIPTION_LIMITS, formatDate } from '@/lib/utils';
import Link from 'next/link';

export default function AccountPage() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [subscription, setSubscription] = useState<any>(null);
  const [form, setForm] = useState({
    full_name: '',
    phone: '',
    specialty: '',
    designation: '',
    institution: '',
    years_of_experience: '',
    bio: '',
    linkedin_url: '',
  });

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const [profileRes, subRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('subscriptions').select('*').eq('user_id', user.id).eq('status', 'active').order('created_at', { ascending: false }).limit(1).maybeSingle(),
      ]);
      if (profileRes.data) {
        setProfile(profileRes.data);
        setForm({
          full_name: profileRes.data.full_name || '',
          phone: profileRes.data.phone || '',
          specialty: profileRes.data.specialty || '',
          designation: profileRes.data.designation || '',
          institution: profileRes.data.institution || '',
          years_of_experience: profileRes.data.years_of_experience?.toString() || '',
          bio: profileRes.data.bio || '',
          linkedin_url: profileRes.data.linkedin_url || '',
        });
      }
      setSubscription(subRes.data);
      setLoading(false);
    };
    load();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const supabase = getSupabase();
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from('profiles').update({
        ...form,
        years_of_experience: parseInt(form.years_of_experience) || 0,
      }).eq('id', user.id);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-teal-500" /></div>;

  const tier = profile?.subscription_tier || 'basic';
  const limits = SUBSCRIPTION_LIMITS[tier as keyof typeof SUBSCRIPTION_LIMITS];
  const tierColors = { basic: 'bg-gray-100 text-gray-700', professional: 'bg-teal-100 text-teal-700', premium: 'bg-yellow-100 text-yellow-700' };

  return (
    <div className="animate-fade-up max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Account Settings</h1>
          <p className="text-gray-500 text-sm mt-1">Manage your profile and subscription</p>
        </div>
        <span className={`badge ${tierColors[tier as keyof typeof tierColors]} capitalize text-sm px-3 py-1`}>
          {tier} Plan
        </span>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white rounded-xl p-1 border border-medical-border mb-6 w-fit">
        {[
          { id: 'profile', icon: User, label: 'Profile' },
          { id: 'subscription', icon: CreditCard, label: 'Subscription' },
          { id: 'security', icon: Shield, label: 'Security' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-navy-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'profile' && (
        <div className="card space-y-5">
          <div className="flex items-center gap-4 pb-4 border-b border-gray-100">
            <div className="w-16 h-16 rounded-full bg-navy-600 flex items-center justify-center text-white font-bold text-2xl">
              {form.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            <div>
              <p className="font-semibold text-gray-900">{form.full_name}</p>
              <p className="text-gray-500 text-sm">{profile?.email}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2 md:col-span-1">
              <label className="label">Full Name</label>
              <input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} className="input-field" />
            </div>
            <div className="col-span-2 md:col-span-1">
              <label className="label">Phone Number</label>
              <input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} className="input-field" placeholder="+91 98765 43210" />
            </div>
            <div>
              <label className="label">Medical Specialty</label>
              <select value={form.specialty} onChange={e => setForm(p => ({ ...p, specialty: e.target.value }))} className="input-field">
                <option value="">Select specialty</option>
                {MEDICAL_SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Designation</label>
              <select value={form.designation} onChange={e => setForm(p => ({ ...p, designation: e.target.value }))} className="input-field">
                <option value="">Select designation</option>
                {['Medical Student', 'Intern', 'Junior Resident', 'Senior Resident', 'Fellow', 'Registrar', 'Consultant', 'Associate Professor', 'Professor', 'HOD/Director', 'Retired'].map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Current Institution</label>
              <input value={form.institution} onChange={e => setForm(p => ({ ...p, institution: e.target.value }))} className="input-field" placeholder="Hospital / Medical College" />
            </div>
            <div>
              <label className="label">Years of Experience</label>
              <input type="number" min={0} max={50} value={form.years_of_experience} onChange={e => setForm(p => ({ ...p, years_of_experience: e.target.value }))} className="input-field" />
            </div>
            <div className="col-span-2">
              <label className="label">Professional Bio</label>
              <textarea value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} className="input-field min-h-[80px] resize-none" placeholder="Brief professional summary..." />
            </div>
            <div className="col-span-2">
              <label className="label">LinkedIn URL</label>
              <input value={form.linkedin_url} onChange={e => setForm(p => ({ ...p, linkedin_url: e.target.value }))} className="input-field" placeholder="https://linkedin.com/in/yourprofile" />
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            {saved && <span className="text-sm text-green-600 flex items-center gap-1.5"><CheckCircle2 size={14} /> Changes saved!</span>}
            <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2 ml-auto">
              {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>
      )}

      {activeTab === 'subscription' && (
        <div className="space-y-4">
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-4">Current Plan</h2>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="font-display text-2xl font-bold text-gray-900 capitalize">{tier} Plan</p>
                {subscription && (
                  <p className="text-sm text-gray-500 mt-1">
                    Renews on {formatDate(subscription.current_period_end)} · {subscription.billing_cycle}
                  </p>
                )}
                {tier === 'basic' && <p className="text-sm text-gray-500 mt-1">Free plan — no billing</p>}
              </div>
              <span className={`badge ${tierColors[tier as keyof typeof tierColors]} capitalize px-3 py-1.5 text-sm`}>{tier}</span>
            </div>

            <div className="border-t border-gray-100 pt-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Plan Features</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'CME Entries', value: limits.cme_entries === 'unlimited' ? 'Unlimited' : `Up to ${limits.cme_entries}` },
                  { label: 'CV Scores/Month', value: limits.cv_scores_per_month === 'unlimited' ? 'Unlimited' : `${limits.cv_scores_per_month}` },
                  { label: 'Career Sessions', value: limits.career_sessions === 'unlimited' ? 'Unlimited' : `${limits.career_sessions}` },
                  { label: 'Interview Sessions', value: limits.interview_sessions_per_month === 'unlimited' ? 'Unlimited' : `${limits.interview_sessions_per_month}/month` },
                ].map(f => (
                  <div key={f.label} className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">{f.label}</p>
                    <p className="font-semibold text-gray-900 text-sm mt-0.5">{f.value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex gap-3">
              {tier === 'basic' && (
                <Link href="/pricing" className="btn-teal flex-1 text-center">Upgrade Plan</Link>
              )}
              {tier === 'professional' && (
                <Link href="/pricing?plan=premium" className="btn-teal flex-1 text-center">Upgrade to Premium</Link>
              )}
              {subscription && (
                <button className="btn-secondary text-sm text-red-500 border-red-200 hover:bg-red-50">Cancel Subscription</button>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'security' && (
        <div className="card space-y-4">
          <h2 className="font-semibold text-gray-900 mb-4">Security Settings</h2>
          <div>
            <label className="label">New Password</label>
            <input type="password" className="input-field" placeholder="Enter new password (min 8 chars)" />
          </div>
          <div>
            <label className="label">Confirm New Password</label>
            <input type="password" className="input-field" placeholder="Confirm new password" />
          </div>
          <button className="btn-primary">Update Password</button>

          <div className="border-t border-gray-100 pt-4 mt-4">
            <h3 className="font-semibold text-red-600 mb-2">Danger Zone</h3>
            <p className="text-sm text-gray-500 mb-3">Permanently delete your account and all associated data. This cannot be undone.</p>
            <button className="text-sm font-semibold text-red-500 hover:text-red-700 px-4 py-2 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
              Delete Account
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
