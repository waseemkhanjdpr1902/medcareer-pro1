'use client';

import { useEffect, useState } from 'react';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from 'recharts';
import { TrendingUp, Activity, Target, MessageSquare, Lock, ArrowUp, ArrowDown } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { formatCredits } from '@/lib/utils';
import Link from 'next/link';

const PIE_COLORS = ['#0D9DA4', '#0A4B6E', '#F5A623', '#22c55e', '#8b5cf6', '#f43f5e', '#64748b', '#f59e0b'];

export default function AnalyticsPage() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [cmeByType, setCmeByType] = useState<any[]>([]);
  const [cmeByMonth, setCmeByMonth] = useState<any[]>([]);
  const [cvScoreHistory, setCvScoreHistory] = useState<any[]>([]);
  const [interviewScores, setInterviewScores] = useState<any[]>([]);
  const [totals, setTotals] = useState({
    cmeCredits: 0, cmeActivities: 0, cvScores: 0, interviewSessions: 0, careerSessions: 0,
  });

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [profileRes, cmeRes, cvRes, interviewRes, careerRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('cme_records').select('*').eq('user_id', user.id).order('completion_date'),
        supabase.from('cv_scores').select('overall_score, scored_at, job_role_targeted').eq('user_id', user.id).order('scored_at'),
        supabase.from('interview_sessions').select('performance_score, interview_type, created_at, status').eq('user_id', user.id).order('created_at'),
        supabase.from('career_sessions').select('id').eq('user_id', user.id),
      ]);

      setProfile(profileRes.data);
      const cmeRecords: any[] = cmeRes.data || [];
      const cvScores: any[] = cvRes.data || [];
      const interviewData: any[] = interviewRes.data || [];

      // Totals
      setTotals({
        cmeCredits: cmeRecords.reduce((s, r) => s + parseFloat(r.credits), 0),
        cmeActivities: cmeRecords.length,
        cvScores: cvScores.length,
        interviewSessions: interviewData.length,
        careerSessions: careerRes.data?.length || 0,
      });

      // CME by type (pie chart)
      const typeMap: Record<string, number> = {};
      cmeRecords.forEach(r => {
        const key = r.activity_type.replace('_', ' ');
        typeMap[key] = (typeMap[key] || 0) + parseFloat(r.credits);
      });
      setCmeByType(Object.entries(typeMap).map(([name, value]) => ({ name: name.charAt(0).toUpperCase() + name.slice(1), value: parseFloat(value.toFixed(1)) })));

      // CME by month (last 12 months)
      const monthMap: Record<string, number> = {};
      for (let i = 11; i >= 0; i--) {
        const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
        monthMap[d.toLocaleString('default', { month: 'short', year: '2-digit' })] = 0;
      }
      cmeRecords.forEach(r => {
        const d = new Date(r.completion_date);
        const key = d.toLocaleString('default', { month: 'short', year: '2-digit' });
        if (key in monthMap) monthMap[key] += parseFloat(r.credits);
      });
      setCmeByMonth(Object.entries(monthMap).map(([month, credits]) => ({ month, credits: parseFloat(credits.toFixed(1)) })));

      // CV score trend
      setCvScoreHistory(cvScores.map(s => ({
        date: new Date(s.scored_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
        score: s.overall_score,
        role: s.job_role_targeted || 'General',
      })));

      // Interview scores
      setInterviewScores(
        interviewData
          .filter(s => s.performance_score && s.status === 'completed')
          .map((s, i) => ({
            session: `#${i + 1}`,
            score: s.performance_score,
            type: s.interview_type,
            date: new Date(s.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
          }))
      );

      setLoading(false);
    };
    load();
  }, []);

  if (profile?.subscription_tier === 'basic') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
        <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mb-4">
          <Lock size={28} className="text-amber-500" />
        </div>
        <h2 className="font-display text-2xl font-bold text-gray-900 mb-2">Analytics Requires Pro</h2>
        <p className="text-gray-500 max-w-sm mb-6 leading-relaxed">
          Unlock detailed career analytics, CME progress charts, CV score trends, and interview performance insights.
        </p>
        <Link href="/pricing?plan=professional" className="btn-teal py-3 px-8 flex items-center gap-2">
          <TrendingUp size={16} /> Upgrade to Professional
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-48 bg-gray-200 rounded-xl" />
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => <div key={i} className="h-24 bg-white rounded-2xl" />)}
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => <div key={i} className="h-64 bg-white rounded-2xl" />)}
        </div>
      </div>
    );
  }

  const lastCvScore = cvScoreHistory[cvScoreHistory.length - 1]?.score || 0;
  const prevCvScore = cvScoreHistory[cvScoreHistory.length - 2]?.score || 0;
  const cvDelta = lastCvScore - prevCvScore;

  const avgInterviewScore = interviewScores.length
    ? Math.round(interviewScores.reduce((s, i) => s + i.score, 0) / interviewScores.length)
    : 0;

  const statCards = [
    { label: 'CME Credits', value: formatCredits(totals.cmeCredits), sub: `${totals.cmeActivities} activities`, icon: Activity, color: 'bg-blue-50', iconColor: 'text-blue-600' },
    { label: 'Latest CV Score', value: lastCvScore ? `${lastCvScore}%` : 'N/A', sub: cvDelta !== 0 ? `${cvDelta > 0 ? '+' : ''}${cvDelta}% change` : 'No prev score', icon: Target, color: 'bg-purple-50', iconColor: 'text-purple-600', delta: cvDelta },
    { label: 'Avg. Interview', value: avgInterviewScore ? `${avgInterviewScore}%` : 'N/A', sub: `${totals.interviewSessions} sessions`, icon: MessageSquare, color: 'bg-orange-50', iconColor: 'text-orange-600' },
    { label: 'Career Sessions', value: totals.careerSessions.toString(), sub: 'AI guidance chats', icon: TrendingUp, color: 'bg-green-50', iconColor: 'text-green-600' },
    { label: 'CV Analyses', value: totals.cvScores.toString(), sub: 'ATS score checks', icon: Target, color: 'bg-teal-50', iconColor: 'text-teal-600' },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-card text-xs">
        <p className="font-semibold text-gray-700 mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-fade-up">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900">Career Analytics</h1>
        <p className="text-gray-500 text-sm mt-1">Visualise your progress across CME, CV performance, and interview practice.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {statCards.map(s => (
          <div key={s.label} className="card">
            <div className={`${s.color} w-9 h-9 rounded-xl flex items-center justify-center mb-3`}>
              <s.icon size={16} className={s.iconColor} />
            </div>
            <div className="flex items-end gap-1.5">
              <span className="font-display text-2xl font-bold text-gray-900">{s.value}</span>
              {'delta' in s && s.delta !== 0 && (
                <span className={`text-xs font-semibold mb-0.5 flex items-center gap-0.5 ${(s.delta as number) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {(s.delta as number) > 0 ? <ArrowUp size={10} /> : <ArrowDown size={10} />}
                  {Math.abs(s.delta as number)}%
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-0.5">{s.sub}</p>
            <p className="text-xs text-gray-500 font-medium mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* CME Credits by Month */}
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-5">CME Credits — Last 12 Months</h2>
          {cmeByMonth.some(m => m.credits > 0) ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={cmeByMonth} barCategoryGap="35%">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="credits" name="Credits" fill="#0D9DA4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyChart message="Add CME activities to see your monthly trends." />
          )}
        </div>

        {/* CME by Activity Type */}
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-5">Credits by Activity Type</h2>
          {cmeByType.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={cmeByType}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {cmeByType.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  iconType="circle"
                  iconSize={8}
                  formatter={(v) => <span className="text-xs text-gray-600">{v}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <EmptyChart message="Log CME activities to see your breakdown by type." />
          )}
        </div>

        {/* CV Score Trend */}
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-5">CV Score Trend</h2>
          {cvScoreHistory.length >= 2 ? (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={cvScoreHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="score"
                  name="ATS Score %"
                  stroke="#8b5cf6"
                  strokeWidth={2.5}
                  dot={{ fill: '#8b5cf6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyChart message="Score your CV at least twice to see the improvement trend." />
          )}
        </div>

        {/* Interview Scores */}
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-5">Interview Performance Over Time</h2>
          {interviewScores.length >= 2 ? (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={interviewScores}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="session" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="score"
                  name="Score %"
                  stroke="#f59e0b"
                  strokeWidth={2.5}
                  dot={{ fill: '#f59e0b', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyChart message="Complete at least 2 mock interviews to see your progress." />
          )}
        </div>
      </div>

      {/* Interview breakdown table */}
      {interviewScores.length > 0 && (
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-4">Interview Session Log</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  {['Session', 'Type', 'Date', 'Score', 'Grade'].map(h => (
                    <th key={h} className="text-left py-2.5 px-3 text-xs font-semibold text-gray-400 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {interviewScores.map((s, i) => {
                  const grade = s.score >= 80 ? { label: 'Excellent', cls: 'bg-green-100 text-green-700' }
                    : s.score >= 65 ? { label: 'Good', cls: 'bg-teal-100 text-teal-700' }
                    : s.score >= 50 ? { label: 'Fair', cls: 'bg-yellow-100 text-yellow-700' }
                    : { label: 'Needs Work', cls: 'bg-red-100 text-red-700' };
                  return (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="py-3 px-3 font-medium text-gray-900">{s.session}</td>
                      <td className="py-3 px-3 capitalize text-gray-600">{s.type}</td>
                      <td className="py-3 px-3 text-gray-500">{s.date}</td>
                      <td className="py-3 px-3 font-bold text-gray-900">{s.score}%</td>
                      <td className="py-3 px-3">
                        <span className={`badge ${grade.cls}`}>{grade.label}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function EmptyChart({ message }: { message: string }) {
  return (
    <div className="h-48 flex flex-col items-center justify-center text-center gap-2">
      <TrendingUp size={28} className="text-gray-200" />
      <p className="text-gray-400 text-sm max-w-48 leading-relaxed">{message}</p>
    </div>
  );
}
