'use client';

import { useEffect, useState } from 'react';
import { Target, Upload, Loader2, TrendingUp, CheckCircle2, AlertTriangle, XCircle, Lock, X } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { getScoreColor, getScoreBg, getScoreLabel } from '@/lib/utils';

interface ScoreResult {
  overall_score: number;
  ats_compatibility_score: number;
  keyword_score: number;
  format_score: number;
  content_score: number;
  completeness_score: number;
  feedback: { strengths: string[]; weaknesses: string[]; suggestions: string[] };
  keywords_found: string[];
  keywords_missing: string[];
  improvements: string[];
}

export default function CvScorePage() {
  const [profile, setProfile] = useState<any>(null);
  const [cvText, setCvText] = useState('');
  const [jobRole, setJobRole] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ScoreResult | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [error, setError] = useState('');
  const [usageCount, setUsageCount] = useState(0);
  const [userId, setUserId] = useState('');

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const [profileRes, scoresRes, usageRes] = await Promise.all([
        supabase.from('profiles').select('subscription_tier').eq('id', user.id).single(),
        supabase.from('cv_scores').select('*').eq('user_id', user.id).order('scored_at', { ascending: false }).limit(5),
        supabase.from('usage_tracking').select('count').eq('user_id', user.id).eq('feature', 'cv_score').eq('month_year', new Date().toISOString().slice(0, 7)).maybeSingle(),
      ]);
      setProfile(profileRes.data);
      setHistory(scoresRes.data || []);
      setUsageCount(usageRes.data?.count || 0);
    };
    load();
  }, []);

  const getLimit = () => {
    if (!profile) return 1;
    if (profile.subscription_tier === 'premium') return Infinity;
    if (profile.subscription_tier === 'professional') return 10;
    return 1;
  };

  const canScore = usageCount < getLimit();

  const handleScore = async () => {
    if (!cvText.trim()) { setError('Please paste your CV content first.'); return; }
    if (!canScore) { setError('Monthly CV score limit reached. Upgrade to score more.'); return; }
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/ai/cv-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cv_text: cvText, job_role: jobRole, user_id: userId }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setResult(data);
      setHistory(p => [{ overall_score: data.overall_score, job_role_targeted: jobRole, scored_at: new Date().toISOString() }, ...p.slice(0, 4)]);
      setUsageCount(p => p + 1);
    } catch (err: any) {
      setError(err.message || 'Failed to score CV. Please try again.');
    }
    setLoading(false);
  };

  const ScoreRing = ({ score, size = 120 }: { score: number; size?: number }) => {
    const r = 45;
    const c = 2 * Math.PI * r;
    const offset = c - (score / 100) * c;
    const color = score >= 80 ? '#22c55e' : score >= 60 ? '#f59e0b' : '#ef4444';
    return (
      <svg width={size} height={size} viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={r} fill="none" stroke="#f1f5f9" strokeWidth="8" />
        <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={offset} transform="rotate(-90 50 50)" style={{ transition: 'stroke-dashoffset 1s ease' }} />
        <text x="50" y="46" textAnchor="middle" fontSize="18" fontWeight="700" fill="#1A202C">{score}</text>
        <text x="50" y="60" textAnchor="middle" fontSize="9" fill="#94a3b8">/ 100</text>
      </svg>
    );
  };

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">CV Score Checker</h1>
          <p className="text-gray-500 text-sm mt-1">Get an AI-powered ATS compatibility score for your CV</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-400">Scores used this month</p>
          <p className="font-bold text-gray-900">{usageCount} / {getLimit() === Infinity ? '∞' : getLimit()}</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Input Panel */}
        <div className="card space-y-4">
          <h2 className="font-semibold text-gray-900">Paste Your CV</h2>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm">{error}</div>
          )}
          <div>
            <label className="label">Target Job Role (Optional)</label>
            <input value={jobRole} onChange={e => setJobRole(e.target.value)} className="input-field" placeholder="e.g., Cardiologist, Senior Resident, Fellowship" />
          </div>
          <div>
            <label className="label">CV Content *</label>
            <textarea
              value={cvText}
              onChange={e => setCvText(e.target.value)}
              className="input-field min-h-[280px] resize-none font-mono text-xs"
              placeholder="Paste your full CV text here — include your education, experience, skills, publications, and awards..."
            />
            <p className="text-xs text-gray-400 mt-1">{cvText.length} characters</p>
          </div>
          {!canScore ? (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
              <Lock size={24} className="mx-auto mb-2 text-amber-500" />
              <p className="text-sm font-semibold text-amber-800">Monthly limit reached</p>
              <p className="text-xs text-amber-600 mt-1">Upgrade your plan to score more CVs</p>
              <a href="/pricing" className="btn-teal mt-3 text-xs py-2 px-5 inline-block">Upgrade Now</a>
            </div>
          ) : (
            <button onClick={handleScore} disabled={loading || !cvText.trim()} className="btn-primary w-full py-3 flex items-center justify-center gap-2">
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Target size={16} />}
              {loading ? 'Analyzing your CV...' : 'Score My CV'}
            </button>
          )}
        </div>

        {/* Result Panel */}
        <div className="space-y-4">
          {loading ? (
            <div className="card flex flex-col items-center justify-center py-20 gap-4">
              <Loader2 size={40} className="animate-spin text-teal-500" />
              <p className="text-gray-500 font-medium">Analyzing your CV...</p>
              <p className="text-gray-400 text-sm">Checking ATS compatibility, keywords, formatting...</p>
            </div>
          ) : result ? (
            <>
              {/* Overall Score */}
              <div className="card text-center">
                <h3 className="font-semibold text-gray-900 mb-4">Overall Score</h3>
                <div className="flex justify-center mb-3">
                  <ScoreRing score={result.overall_score} size={140} />
                </div>
                <p className={`font-bold text-lg ${getScoreColor(result.overall_score)}`}>{getScoreLabel(result.overall_score)}</p>
                {jobRole && <p className="text-xs text-gray-400 mt-1">For: {jobRole}</p>}
              </div>

              {/* Sub-scores */}
              <div className="card">
                <h3 className="font-semibold text-gray-900 mb-4">Score Breakdown</h3>
                <div className="space-y-3">
                  {[
                    { label: 'ATS Compatibility', score: result.ats_compatibility_score },
                    { label: 'Keywords', score: result.keyword_score },
                    { label: 'Format & Structure', score: result.format_score },
                    { label: 'Content Quality', score: result.content_score },
                    { label: 'Completeness', score: result.completeness_score },
                  ].map(s => (
                    <div key={s.label}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium text-gray-700">{s.label}</span>
                        <span className={`font-bold ${getScoreColor(s.score)}`}>{s.score}%</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${s.score >= 80 ? 'bg-green-500' : s.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{ width: `${s.score}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Feedback */}
              {result.feedback?.strengths?.length > 0 && (
                <div className="card">
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2"><CheckCircle2 size={16} className="text-green-500" /> Strengths</h3>
                  <ul className="space-y-2">
                    {result.feedback.strengths.map((s: string, i: number) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle2 size={14} className="text-green-500 flex-shrink-0 mt-0.5" /> {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {result.improvements?.length > 0 && (
                <div className="card">
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2"><TrendingUp size={16} className="text-orange-500" /> Top Improvements</h3>
                  <ul className="space-y-2">
                    {result.improvements.slice(0, 5).map((s: string, i: number) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <AlertTriangle size={14} className="text-orange-500 flex-shrink-0 mt-0.5" /> {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {result.keywords_missing?.length > 0 && (
                <div className="card">
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2"><XCircle size={16} className="text-red-500" /> Missing Keywords</h3>
                  <div className="flex flex-wrap gap-2">
                    {result.keywords_missing.map((k: string) => (
                      <span key={k} className="bg-red-50 text-red-600 text-xs px-2.5 py-1 rounded-full border border-red-100">{k}</span>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="card flex flex-col items-center justify-center py-20 text-center">
              <Target size={48} className="text-gray-200 mb-4" />
              <p className="font-semibold text-gray-900 mb-2">Ready to score your CV</p>
              <p className="text-gray-400 text-sm max-w-xs">Paste your CV content on the left and click Score to get detailed AI feedback and ATS compatibility analysis.</p>
            </div>
          )}

          {/* History */}
          {history.length > 0 && (
            <div className="card">
              <h3 className="font-semibold text-gray-900 mb-3">Score History</h3>
              <div className="space-y-2">
                {history.map((h, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div>
                      <p className="text-sm font-medium text-gray-700">{h.job_role_targeted || 'General CV'}</p>
                      <p className="text-xs text-gray-400">{new Date(h.scored_at).toLocaleDateString('en-IN')}</p>
                    </div>
                    <span className={`font-bold text-sm ${getScoreColor(h.overall_score)}`}>{h.overall_score}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
