'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  Activity, FileText, BrainCircuit, MessageSquare, Target,
  Settings, LogOut, Stethoscope, Menu, X, Zap, Bell, Home,
  TrendingUp, ChevronRight
} from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: Home, description: 'Overview' },
  { href: '/cme-tracker', label: 'CME Tracker', icon: Activity, description: 'Track credits' },
  { href: '/cv-builder', label: 'CV Builder', icon: FileText, description: 'Build your CV' },
  { href: '/cv-score', label: 'CV Score', icon: Target, description: 'ATS analysis' },
  { href: '/career-guidance', label: 'Career Advisor', icon: BrainCircuit, description: 'AI guidance' },
  { href: '/mock-interview', label: 'Mock Interview', icon: MessageSquare, description: 'Practice sessions' },
  { href: '/analytics', label: 'Analytics', icon: TrendingUp, description: 'Career insights' },
];

const TIER_COLORS = {
  basic: { badge: 'bg-gray-100 text-gray-600', label: 'Basic' },
  professional: { badge: 'bg-teal-100 text-teal-700', label: 'Professional' },
  premium: { badge: 'bg-amber-100 text-amber-700', label: 'Premium' },
};

export default function DashboardGroupLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push('/auth/login'); return; }
      const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      setProfile(data);
    };
    fetchProfile();
  }, [router]);

  const handleSignOut = async () => {
    const supabase = getSupabase();
    await supabase.auth.signOut();
    router.push('/');
  };

  const tier = (profile?.subscription_tier || 'basic') as keyof typeof TIER_COLORS;
  const tierInfo = TIER_COLORS[tier];

  return (
    <div className="flex h-screen bg-medical-bg overflow-hidden">
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── Sidebar ── */}
      <aside className={cn(
        'fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-100 flex flex-col shadow-xl transition-transform duration-300 ease-in-out',
        'lg:relative lg:translate-x-0 lg:shadow-none',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        {/* Logo */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-navy-600 rounded-lg flex items-center justify-center group-hover:bg-navy-700 transition-colors">
              <Stethoscope size={16} className="text-white" />
            </div>
            <span className="font-display text-lg font-bold text-navy-600">MedCareer Pro</span>
          </Link>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600"
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(item => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all duration-150',
                  isActive
                    ? 'bg-navy-600 text-white shadow-sm'
                    : 'text-gray-500 hover:text-navy-700 hover:bg-navy-50'
                )}
              >
                <item.icon size={17} className="flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <span className="block truncate">{item.label}</span>
                </div>
                {isActive && <ChevronRight size={14} className="flex-shrink-0 opacity-70" />}
              </Link>
            );
          })}
        </nav>

        {/* Upgrade Banner — only for basic users */}
        {tier === 'basic' && (
          <div className="mx-3 mb-3 p-4 bg-gradient-to-br from-navy-700 to-teal-600 rounded-xl text-white overflow-hidden relative">
            <div className="absolute -top-3 -right-3 w-16 h-16 bg-white/5 rounded-full" />
            <div className="flex items-center gap-2 mb-1.5">
              <Zap size={14} className="text-amber-300 flex-shrink-0" />
              <span className="text-xs font-bold">Upgrade to Pro</span>
            </div>
            <p className="text-xs text-white/75 mb-3 leading-relaxed">
              Unlock AI tools, unlimited CME tracking and interview practice.
            </p>
            <Link
              href="/pricing"
              className="block text-center bg-white text-navy-700 rounded-lg py-1.5 text-xs font-bold hover:bg-gray-50 transition-colors"
            >
              View Plans →
            </Link>
          </div>
        )}

        {/* User Section */}
        <div className="px-3 pb-4 border-t border-gray-100 pt-3">
          <div className="flex items-center gap-3 px-1 mb-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-navy-600 to-teal-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0 shadow-sm">
              {profile?.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">{profile?.full_name || '...'}</p>
              <span className={`badge ${tierInfo.badge} text-xs`}>{tierInfo.label}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5 mt-2">
            <Link
              href="/account"
              onClick={() => setSidebarOpen(false)}
              className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium text-gray-500 hover:text-navy-700 hover:bg-navy-50 transition-colors"
            >
              <Settings size={13} />
              Settings
            </Link>
            <button
              onClick={handleSignOut}
              className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium text-red-400 hover:text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut size={13} />
              Sign out
            </button>
          </div>
        </div>
      </aside>

      {/* ── Main Area ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-100 px-4 lg:px-6 py-3 flex items-center gap-3 flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"
          >
            <Menu size={20} />
          </button>

          {/* Breadcrumb */}
          <div className="hidden md:flex items-center gap-1.5 text-sm text-gray-400">
            <span className="font-medium text-gray-700">
              {NAV_ITEMS.find(n => n.href === pathname)?.label || 'Dashboard'}
            </span>
          </div>

          <div className="ml-auto flex items-center gap-2">
            {tier !== 'premium' && (
              <Link
                href="/pricing"
                className="hidden md:flex items-center gap-1.5 text-xs font-semibold text-teal-600 hover:text-teal-700 bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-lg transition-colors"
              >
                <Zap size={12} />
                Upgrade
              </Link>
            )}
            <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
              <Bell size={18} />
            </button>
            <Link href="/account" className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-navy-600 to-teal-600 flex items-center justify-center text-white font-bold text-xs shadow-sm">
                {profile?.full_name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
