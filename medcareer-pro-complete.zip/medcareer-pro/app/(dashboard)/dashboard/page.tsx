'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Activity, FileText, MessageSquare, Target, TrendingUp, BrainCircuit, ArrowRight, Calendar, Clock, Star } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { formatDate, formatCredits } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function DashboardPage() {
  const [profile, setProfile] = useState<any>(null);
  const [stats, setStats] = useState({
    totalCmeCredits: 0,
    cmeThisYear: 0,
    cvScore: 0,
    interviewSessions: 0,
    careerSessions: 0,
    cmeRecords: 0,
  });
  const [recentCme, setRecentCme] = useState<any[]>([]);
  const [cmeChartData, setCmeChartData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [profileRes, cmeRes, cvScoreRes, interviewRes, careerRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('cme_records').select('*').eq('user_id', user.id).order('completion_date', { ascending: false }),
        supabase.from('cv_scores').select('overall_score, scored_at').eq('user_id', user.id).order('scored_at', { ascending: false }).limit(1),
        supabase.from('interview_sessions').select('id').eq('user_id', user.id),
        supabase.from('career_sessions').select('id').eq('user_id', user.id),
      ]);

      setProfile(profileRes.data);
      const records = cmeRes.data || [];
      const thisYear = new Date().getFullYear();
      const total = records.reduce((s: number, r: any) => s + parseFloat(r.credits || 0), 0);
      const yearCredits = records.filter((r: any) => new Date(r.completion_date).getFullYear() === thisYear)
        .reduce((s: number, r: any) => s + parseFloat(r.credits || 0), 0);

      setStats({
        totalCmeCredits: total,
        cmeThisYear: yearCredits,
        cvScore: cvScoreRes.data?.[0]?.overall_score || 0,
        interviewSessions: interviewRes.data?.length || 0,
        careerSessions: careerRes.data?.length || 0,
        cmeRecords: records.length,
      });
      setRecentCme(records.slice(0, 5));

      // Monthly CME chart data (last 6 months)
      const months: Record<string, number> = {};
      for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        const key = d.toLocaleString('default', { month: 'short' });
        months[key] = 0;
      }
      records.forEach((r: any) => {
        const d = new Date(r.completion_date);
        const monthsAgo = (new Date().getFullYear() - d.getFullYear()) * 12 + (new Date().getMonth() - d.getMonth());
        if (monthsAgo < 6) {
          const key = d.toLocaleString('default', { month: 'short' });
          if (key in months) months[key] += parseFloat(r.credits || 0);
        }
      });
      setCmeChartData(Object.entries(months).map(([month, credits]) => ({ month, credits })));
      setLoading(false);
    };
    load();
  }, []);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  const QUICK_ACTIONS = [
    { href: '/cme-tracker', icon: Activity, label: 'Add CME Credit', color: 'bg-blue-500', desc: 'Log your latest CME activity' },
    { href: '/cv-score', icon: Target, label: 'Check CV Score', color: 'bg-purple-500', desc: 'Get your ATS compatibility score' },
    { href: '/career-guidance', icon: BrainCircuit, label: 'Career Advice', color: 'bg-green-500', desc: 'Chat with your AI career advisor' },
    { href: '/mock-interview', icon: MessageSquare, label: 'Mock Interview', color: 'bg-orange-500', desc: 'Practice with AI interviewer' },
  ];

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-32 bg-white rounded-2xl" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-28 bg-white rounded-2xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-up">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-gray-900">
            {greeting}, {profile?.full_name?.split(' ')[0] || 'Doctor'} 👋
          </h1>
          <p className="text-gray-500 mt-1">
            {profile?.specialty && `${profile.specialty} · `}
            Here's your career snapshot
          </p>
        </div>
        <div className="hidden md:flex items-center gap-2 text-sm text-gray-500">
          <Calendar size={14} />
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total CME Credits', value: formatCredits(stats.totalCmeCredits), sub: `${formatCredits(stats.cmeThisYear)} this year`, icon: Activity, color: 'bg-blue-50', iconColor: 'text-blue-600' },
          { label: 'CME Activities', value: stats.cmeRecords.toString(), sub: 'Logged activities', icon: Star, color: 'bg-teal-50', iconColor: 'text-teal-600' },
          { label: 'Latest CV Score', value: stats.cvScore ? `${stats.cvScore}%` : 'N/A', sub: stats.cvScore >= 70 ? 'Good ATS fit' : stats.cvScore > 0 ? 'Needs improvement' : 'Not scored yet', icon: Target, color: 'bg-purple-50', iconColor: 'text-purple-600' },
          { label: 'Interview Sessions', value: stats.interviewSessions.toString(), sub: 'Practice sessions', icon: MessageSquare, color: 'bg-orange-50', iconColor: 'text-orange-600' },
        ].map(stat => (
          <div key={stat.label} className="card">
            <div className={`${stat.color} w-10 h-10 rounded-xl flex items-center justify-center mb-3`}>
              <stat.icon size={18} className={stat.iconColor} />
            </div>
            <div className="font-display text-2xl font-bold text-gray-900">{stat.value}</div>
            <div className="text-xs font-medium text-gray-500 mt-0.5">{stat.sub}</div>
            <div className="text-xs text-gray-400 mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* CME Chart */}
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold text-gray-900">CME Credits (Last 6 Months)</h2>
            <Link href="/cme-tracker" className="text-xs text-teal-600 font-semibold hover:text-teal-700 flex items-center gap-1">
              View all <ArrowRight size={12} />
            </Link>
          </div>
          {cmeChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={cmeChartData} barCategoryGap="30%">
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }} />
                <Bar dataKey="credits" fill="#0D9DA4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">
              No CME data yet. <Link href="/cme-tracker" className="ml-1 text-teal-600 font-medium">Add your first entry →</Link>
            </div>
          )}
        </div>

        {/* Recent CME */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-900">Recent CME</h2>
            <Link href="/cme-tracker" className="text-xs text-teal-600 font-semibold hover:text-teal-700">View all</Link>
          </div>
          {recentCme.length > 0 ? (
            <ul className="space-y-3">
              {recentCme.map(r => (
                <li key={r.id} className="flex items-start gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className="w-8 h-8 bg-teal-50 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Activity size={14} className="text-teal-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{r.title}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-teal-600 font-semibold">{formatCredits(r.credits)} credits</span>
                      <span className="text-xs text-gray-400">{formatDate(r.completion_date)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-6 text-gray-400 text-sm">
              <Activity size={24} className="mx-auto mb-2 text-gray-300" />
              No CME records yet
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {QUICK_ACTIONS.map(action => (
            <Link key={action.href} href={action.href} className="card-hover group flex flex-col items-start">
              <div className={`${action.color} w-10 h-10 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <action.icon size={18} className="text-white" />
              </div>
              <p className="font-semibold text-gray-900 text-sm">{action.label}</p>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">{action.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
