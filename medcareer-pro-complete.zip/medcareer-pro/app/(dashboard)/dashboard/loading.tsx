export default function DashboardLoading() {
  return (
    <div className="space-y-6 animate-pulse">
      {/* Header skeleton */}
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <div className="h-8 w-64 bg-gray-200 rounded-xl" />
          <div className="h-4 w-40 bg-gray-100 rounded-lg" />
        </div>
        <div className="h-6 w-32 bg-gray-100 rounded-lg hidden md:block" />
      </div>

      {/* Stats grid skeleton */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-2xl p-5 border border-gray-100">
            <div className="w-10 h-10 bg-gray-100 rounded-xl mb-3" />
            <div className="h-7 w-16 bg-gray-200 rounded-lg mb-2" />
            <div className="h-3 w-24 bg-gray-100 rounded" />
          </div>
        ))}
      </div>

      {/* Chart + sidebar skeleton */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100 h-64" />
        <div className="bg-white rounded-2xl p-6 border border-gray-100 h-64" />
      </div>

      {/* Quick actions skeleton */}
      <div>
        <div className="h-5 w-28 bg-gray-200 rounded-lg mb-4" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl p-5 border border-gray-100 h-28" />
          ))}
        </div>
      </div>
    </div>
  );
}
