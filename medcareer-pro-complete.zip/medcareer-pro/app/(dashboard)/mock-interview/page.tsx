'use client';

import { useEffect, useState, useRef } from 'react';
import { MessageSquare, Send, Plus, Loader2, Lock, Star, Mic, StopCircle, Trophy, ChevronRight } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';

const INTERVIEW_TYPES = [
  { value: 'clinical', label: '🏥 Clinical', desc: 'Patient cases, clinical reasoning' },
  { value: 'behavioral', label: '🧠 Behavioral', desc: 'Situational and behavioral questions' },
  { value: 'fellowship', label: '🎓 Fellowship', desc: 'Fellowship interview preparation' },
  { value: 'residency', label: '👩‍⚕️ Residency', desc: 'Residency program interviews' },
  { value: 'technical', label: '⚕️ Technical', desc: 'Specialty-specific technical questions' },
  { value: 'management', label: '📊 Management', desc: 'Hospital admin and leadership roles' },
  { value: 'academic', label: '📚 Academic', desc: 'Teaching faculty and research positions' },
];

interface Message { role: 'user' | 'assistant'; content: string; }

export default function MockInterviewPage() {
  const [profile, setProfile] = useState<any>(null);
  const [sessions, setSessions] = useState<any[]>([]);
  const [activeSession, setActiveSession] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState('');
  const [interviewType, setInterviewType] = useState('behavioral');
  const [roleApplied, setRoleApplied] = useState('');
  const [showSetup, setShowSetup] = useState(true);
  const [monthlyCount, setMonthlyCount] = useState(0);
  const [sessionEnded, setSessionEnded] = useState(false);
  const [feedback, setFeedback] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const startTimeRef = useRef<Date | null>(null);

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const monthYear = new Date().toISOString().slice(0, 7);
      const [profileRes, sessionsRes, usageRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('interview_sessions').select('id, interview_type, role_applied, status, performance_score, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10),
        supabase.from('usage_tracking').select('count').eq('user_id', user.id).eq('feature', 'mock_interview').eq('month_year', monthYear).maybeSingle(),
      ]);
      setProfile(profileRes.data);
      setSessions(sessionsRes.data || []);
      setMonthlyCount(usageRes.data?.count || 0);
    };
    load();
  }, []);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const getLimit = () => {
    if (!profile) return 2;
    if (profile.subscription_tier === 'premium') return Infinity;
    if (profile.subscription_tier === 'professional') return 15;
    return 2;
  };

  const canInterview = monthlyCount < getLimit();

  const startInterview = async () => {
    if (!canInterview) return;
    const supabase = getSupabase();
    const { data } = await supabase.from('interview_sessions').insert({
      user_id: userId,
      interview_type: interviewType,
      specialty: profile?.specialty,
      role_applied: roleApplied || `${profile?.specialty} Position`,
      messages: [],
      status: 'in_progress',
    }).select().single();

    if (data) {
      setActiveSession(data);
      setSessions(p => [data, ...p]);
      setShowSetup(false);
      startTimeRef.current = new Date();
      setMessages([]);
      setMonthlyCount(p => p + 1);

      // Get opening question from AI
      setLoading(true);
      try {
        const res = await fetch('/api/ai/mock-interview', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'start',
            interview_type: interviewType,
            role_applied: roleApplied || `${profile?.specialty} Position`,
            specialty: profile?.specialty,
            messages: [],
          }),
        });
        const aiData = await res.json();
        const openingMsg: Message = { role: 'assistant', content: aiData.response };
        setMessages([openingMsg]);
        await supabase.from('interview_sessions').update({ messages: [openingMsg] }).eq('id', data.id);
      } catch {
        setMessages([{ role: 'assistant', content: 'Welcome to your mock interview! I\'ll be your interviewer today. Could you please start by introducing yourself and telling me about your background?' }]);
      }
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading || sessionEnded) return;
    const userMsg: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/mock-interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'respond',
          messages: newMessages,
          interview_type: interviewType,
          role_applied: roleApplied || `${profile?.specialty} Position`,
          specialty: profile?.specialty,
        }),
      });
      const data = await res.json();
      const assistantMsg: Message = { role: 'assistant', content: data.response };
      const finalMessages = [...newMessages, assistantMsg];
      setMessages(finalMessages);

      const supabase = getSupabase();
      if (activeSession) {
        await supabase.from('interview_sessions').update({ messages: finalMessages }).eq('id', activeSession.id);
      }

      // End session after ~10 exchanges
      if (newMessages.filter(m => m.role === 'user').length >= 8) {
        await endInterview(finalMessages);
      }
    } catch {
      setMessages(p => [...p, { role: 'assistant', content: 'Sorry, something went wrong. Please try again.' }]);
    }
    setLoading(false);
  };

  const endInterview = async (finalMessages: Message[]) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/mock-interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'evaluate',
          messages: finalMessages,
          interview_type: interviewType,
          specialty: profile?.specialty,
        }),
      });
      const data = await res.json();
      setFeedback(data.evaluation);
      setSessionEnded(true);

      const supabase = getSupabase();
      const duration = startTimeRef.current ? Math.round((Date.now() - startTimeRef.current.getTime()) / 60000) : 0;
      if (activeSession) {
        await supabase.from('interview_sessions').update({
          messages: finalMessages,
          status: 'completed',
          performance_score: data.evaluation?.overall_score || 0,
          strengths: data.evaluation?.strengths || [],
          improvements: data.evaluation?.improvements || [],
          feedback_summary: data.evaluation?.summary || '',
          duration_minutes: duration,
        }).eq('id', activeSession.id);
      }
    } catch {}
    setLoading(false);
  };

  const loadSession = async (sessionId: string) => {
    const supabase = getSupabase();
    const { data } = await supabase.from('interview_sessions').select('*').eq('id', sessionId).single();
    if (data) {
      setActiveSession(data);
      setMessages(data.messages || []);
      setInterviewType(data.interview_type);
      setRoleApplied(data.role_applied || '');
      setShowSetup(false);
      setSessionEnded(data.status === 'completed');
      if (data.status === 'completed' && data.performance_score) {
        setFeedback({ overall_score: data.performance_score, summary: data.feedback_summary, strengths: data.strengths, improvements: data.improvements });
      }
    }
  };

  return (
    <div className="animate-fade-up h-[calc(100vh-120px)] flex gap-6">
      {/* Sidebar */}
      <div className="w-64 flex-shrink-0 flex flex-col gap-3">
        <div className="card p-3">
          <button onClick={() => { setShowSetup(true); setActiveSession(null); setMessages([]); setSessionEnded(false); setFeedback(null); }} className="w-full btn-teal py-2.5 text-sm flex items-center justify-center gap-2" disabled={!canInterview}>
            <Plus size={16} /> New Interview
          </button>
          {profile?.subscription_tier === 'basic' && (
            <p className="text-xs text-center text-gray-400 mt-2">{monthlyCount} / 2 used this month</p>
          )}
        </div>

        <div className="card p-3 flex-1 overflow-y-auto">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Recent Sessions</h3>
          {sessions.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-4">No sessions yet</p>
          ) : (
            <ul className="space-y-1">
              {sessions.map(s => (
                <li key={s.id}>
                  <button onClick={() => loadSession(s.id)} className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all ${activeSession?.id === s.id ? 'bg-navy-600 text-white' : 'hover:bg-gray-100 text-gray-600'}`}>
                    <p className="font-medium">{s.interview_type.charAt(0).toUpperCase() + s.interview_type.slice(1)} Interview</p>
                    <div className="flex items-center justify-between mt-0.5">
                      <p className={activeSession?.id === s.id ? 'text-white/60' : 'text-gray-400'}>
                        {new Date(s.created_at).toLocaleDateString('en-IN')}
                      </p>
                      {s.performance_score && (
                        <span className={`font-bold ${s.performance_score >= 70 ? 'text-green-500' : 'text-orange-400'}`}>{s.performance_score}%</span>
                      )}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 card flex flex-col min-h-0 p-0 overflow-hidden">
        {showSetup ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl flex items-center justify-center mb-4">
              <MessageSquare size={28} className="text-white" />
            </div>
            <h2 className="font-display text-2xl font-bold text-gray-900 mb-2">Mock Interview Practice</h2>
            <p className="text-gray-500 text-sm text-center max-w-sm mb-8">Practice with an AI interviewer tailored for medical professionals. Get real-time feedback and performance scores.</p>

            {!canInterview ? (
              <div className="text-center">
                <Lock size={32} className="mx-auto mb-3 text-gray-300" />
                <p className="font-semibold text-gray-900">Monthly limit reached</p>
                <p className="text-gray-400 text-sm mt-1">Upgrade to practice more interviews this month</p>
                <a href="/pricing" className="btn-teal mt-4 inline-block">Upgrade Plan</a>
              </div>
            ) : (
              <div className="w-full max-w-sm space-y-4">
                <div>
                  <label className="label">Interview Type</label>
                  <div className="grid grid-cols-2 gap-2">
                    {INTERVIEW_TYPES.map(t => (
                      <button
                        key={t.value}
                        onClick={() => setInterviewType(t.value)}
                        className={`text-left p-3 rounded-xl border-2 text-sm transition-all ${interviewType === t.value ? 'border-teal-500 bg-teal-50' : 'border-gray-200 hover:border-gray-300'}`}
                      >
                        <p className="font-semibold text-gray-900">{t.label}</p>
                        <p className="text-xs text-gray-500 mt-0.5">{t.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="label">Role / Position Applying For</label>
                  <input value={roleApplied} onChange={e => setRoleApplied(e.target.value)} className="input-field" placeholder={`e.g., Senior Resident in ${profile?.specialty || 'Medicine'}`} />
                </div>
                <button onClick={startInterview} disabled={loading} className="btn-teal w-full py-3 flex items-center justify-center gap-2">
                  {loading ? <Loader2 size={16} className="animate-spin" /> : <MessageSquare size={16} />}
                  Start Interview
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Interview header */}
            <div className="p-4 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
              <div className="w-9 h-9 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl flex items-center justify-center">
                <MessageSquare size={16} className="text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-900 text-sm">{interviewType.charAt(0).toUpperCase() + interviewType.slice(1)} Interview</p>
                <p className="text-xs text-gray-400">{roleApplied || `${profile?.specialty} Position`}</p>
              </div>
              {!sessionEnded && (
                <button onClick={() => endInterview(messages)} className="ml-auto text-xs text-orange-600 hover:text-orange-700 font-semibold flex items-center gap-1.5 px-3 py-1.5 border border-orange-200 hover:bg-orange-50 rounded-lg transition-colors">
                  <StopCircle size={14} /> End & Get Feedback
                </button>
              )}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 bg-gradient-to-br from-orange-400 to-red-500 rounded-lg flex items-center justify-center flex-shrink-0 mr-2 mt-0.5">
                      <MessageSquare size={13} className="text-white" />
                    </div>
                  )}
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${msg.role === 'user' ? 'chat-bubble-user rounded-br-sm' : 'chat-bubble-ai rounded-bl-sm text-gray-800'}`}>
                    {msg.content.split('\n').map((line, j) => <p key={j} className={j > 0 ? 'mt-2' : ''}>{line}</p>)}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="w-7 h-7 bg-gradient-to-br from-orange-400 to-red-500 rounded-lg flex items-center justify-center mr-2 mt-0.5">
                    <MessageSquare size={13} className="text-white" />
                  </div>
                  <div className="chat-bubble-ai rounded-2xl rounded-bl-sm px-4 py-3">
                    <div className="flex gap-1.5 items-center h-5">
                      {[0,1,2].map(i => <div key={i} className="w-1.5 h-1.5 bg-gray-400 rounded-full typing-dot" style={{ animationDelay: `${i * 0.2}s` }} />)}
                    </div>
                  </div>
                </div>
              )}

              {/* Feedback panel */}
              {sessionEnded && feedback && (
                <div className="border-2 border-teal-200 bg-teal-50 rounded-2xl p-6 mt-4">
                  <div className="flex items-center gap-3 mb-4">
                    <Trophy size={24} className="text-gold-500" />
                    <h3 className="font-display text-xl font-bold text-gray-900">Interview Complete!</h3>
                  </div>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="text-center">
                      <div className={`text-4xl font-display font-bold ${feedback.overall_score >= 70 ? 'text-green-600' : feedback.overall_score >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>{feedback.overall_score}%</div>
                      <div className="text-xs text-gray-500">Overall Score</div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-700 leading-relaxed">{feedback.summary}</p>
                    </div>
                  </div>
                  {feedback.strengths?.length > 0 && (
                    <div className="mb-3">
                      <p className="text-xs font-semibold text-green-700 uppercase tracking-wide mb-1.5">💪 Strengths</p>
                      <ul className="space-y-1">
                        {feedback.strengths.map((s: string, i: number) => <li key={i} className="text-sm text-gray-700 flex items-start gap-2"><span className="text-green-500 flex-shrink-0">✓</span>{s}</li>)}
                      </ul>
                    </div>
                  )}
                  {feedback.improvements?.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1.5">📈 Areas to Improve</p>
                      <ul className="space-y-1">
                        {feedback.improvements.map((s: string, i: number) => <li key={i} className="text-sm text-gray-700 flex items-start gap-2"><span className="text-orange-500 flex-shrink-0">→</span>{s}</li>)}
                      </ul>
                    </div>
                  )}
                  <button onClick={() => { setShowSetup(true); setMessages([]); setSessionEnded(false); setFeedback(null); setActiveSession(null); }} className="mt-4 btn-teal text-sm py-2 w-full">
                    Practice Another Interview
                  </button>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            {!sessionEnded && (
              <div className="p-4 border-t border-gray-100 flex-shrink-0">
                <div className="flex items-end gap-3">
                  <textarea
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                    className="flex-1 input-field resize-none min-h-[44px] max-h-[120px] py-3"
                    placeholder="Type your answer here... (be detailed and structured)"
                    rows={1}
                  />
                  <button onClick={handleSend} disabled={loading || !input.trim()} className="btn-teal p-3 rounded-xl flex-shrink-0">
                    {loading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
