'use client';

import { useEffect, useState } from 'react';
import { Activity, Plus, Trash2, Upload, X, Loader2, Filter, Download, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import { getSupabase } from '@/lib/supabase-client';
import { formatDate, formatCredits, CME_ACTIVITY_TYPES } from '@/lib/utils';

interface CmeRecord {
  id: string;
  title: string;
  provider: string;
  activity_type: string;
  credits: number;
  credit_type: string;
  completion_date: string;
  expiry_date?: string;
  certificate_url?: string;
  notes?: string;
  is_mandatory: boolean;
  verification_status: string;
}

const EMPTY_FORM = {
  title: '',
  provider: '',
  activity_type: 'conference',
  credits: '',
  credit_type: 'AMA PRA Category 1',
  completion_date: '',
  expiry_date: '',
  notes: '',
  is_mandatory: false,
};

export default function CmeTrackerPage() {
  const [records, setRecords] = useState<CmeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [filter, setFilter] = useState('all');
  const [userId, setUserId] = useState('');
  const [requirements, setRequirements] = useState<any[]>([]);
  const [showReqForm, setShowReqForm] = useState(false);
  const [reqForm, setReqForm] = useState({
    requirement_name: '',
    total_credits_required: '',
    period_months: '24',
    start_date: '',
    end_date: '',
    license_board: '',
  });

  useEffect(() => {
    const load = async () => {
      const supabase = getSupabase();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const [recRes, reqRes] = await Promise.all([
        supabase.from('cme_records').select('*').eq('user_id', user.id).order('completion_date', { ascending: false }),
        supabase.from('cme_requirements').select('*').eq('user_id', user.id),
      ]);
      setRecords(recRes.data || []);
      setRequirements(reqRes.data || []);
      setLoading(false);
    };
    load();
  }, []);

  const update = (field: string, value: any) => setForm(p => ({ ...p, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const supabase = getSupabase();
    const { data, error } = await supabase.from('cme_records').insert({
      user_id: userId,
      title: form.title,
      provider: form.provider,
      activity_type: form.activity_type,
      credits: parseFloat(form.credits),
      credit_type: form.credit_type,
      completion_date: form.completion_date,
      expiry_date: form.expiry_date || null,
      notes: form.notes || null,
      is_mandatory: form.is_mandatory,
    }).select().single();

    if (!error && data) {
      setRecords(p => [data, ...p]);
      setForm(EMPTY_FORM);
      setShowForm(false);
    }
    setSubmitting(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this CME record?')) return;
    const supabase = getSupabase();
    await supabase.from('cme_records').delete().eq('id', id);
    setRecords(p => p.filter(r => r.id !== id));
  };

  const handleAddRequirement = async (e: React.FormEvent) => {
    e.preventDefault();
    const supabase = getSupabase();
    const { data, error } = await supabase.from('cme_requirements').insert({
      user_id: userId,
      ...reqForm,
      total_credits_required: parseFloat(reqForm.total_credits_required),
      period_months: parseInt(reqForm.period_months),
    }).select().single();
    if (!error && data) {
      setRequirements(p => [...p, data]);
      setShowReqForm(false);
      setReqForm({ requirement_name: '', total_credits_required: '', period_months: '24', start_date: '', end_date: '', license_board: '' });
    }
  };

  const filteredRecords = records.filter(r => {
    if (filter === 'all') return true;
    return r.activity_type === filter;
  });

  const totalCredits = records.reduce((s, r) => s + parseFloat(String(r.credits)), 0);
  const thisYearCredits = records
    .filter(r => new Date(r.completion_date).getFullYear() === new Date().getFullYear())
    .reduce((s, r) => s + parseFloat(String(r.credits)), 0);
  const mandatoryCredits = records.filter(r => r.is_mandatory).reduce((s, r) => s + parseFloat(String(r.credits)), 0);

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-teal-500" size={32} /></div>;

  return (
    <div className="space-y-6 animate-fade-up">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">CME Tracker</h1>
          <p className="text-gray-500 text-sm mt-1">Track and manage your Continuing Medical Education credits</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowReqForm(true)} className="btn-secondary text-sm py-2 px-4">
            + Set Requirement
          </button>
          <button onClick={() => setShowForm(true)} className="btn-teal text-sm py-2 px-4 flex items-center gap-2">
            <Plus size={16} /> Add CME
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Credits', value: formatCredits(totalCredits), icon: Activity, color: 'bg-blue-50', iconColor: 'text-blue-600' },
          { label: 'This Year', value: formatCredits(thisYearCredits), icon: CheckCircle2, color: 'bg-green-50', iconColor: 'text-green-600' },
          { label: 'Mandatory Credits', value: formatCredits(mandatoryCredits), icon: AlertCircle, color: 'bg-orange-50', iconColor: 'text-orange-600' },
          { label: 'Total Activities', value: records.length.toString(), icon: Clock, color: 'bg-purple-50', iconColor: 'text-purple-600' },
        ].map(s => (
          <div key={s.label} className="card flex items-center gap-3">
            <div className={`${s.color} w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`}>
              <s.icon size={18} className={s.iconColor} />
            </div>
            <div>
              <div className="font-display text-xl font-bold text-gray-900">{s.value}</div>
              <div className="text-xs text-gray-500">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Requirements */}
      {requirements.length > 0 && (
        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-4">CME Requirements Progress</h2>
          <div className="space-y-4">
            {requirements.map(req => {
              const startDate = new Date(req.start_date);
              const endDate = new Date(req.end_date);
              const earned = records
                .filter(r => new Date(r.completion_date) >= startDate && new Date(r.completion_date) <= endDate)
                .reduce((s, r) => s + parseFloat(String(r.credits)), 0);
              const pct = Math.min(100, (earned / req.total_credits_required) * 100);
              const daysLeft = Math.ceil((endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              return (
                <div key={req.id} className="border border-gray-100 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <p className="font-semibold text-gray-900 text-sm">{req.requirement_name}</p>
                      {req.license_board && <p className="text-xs text-gray-500">{req.license_board}</p>}
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-teal-600">{formatCredits(earned)} / {req.total_credits_required} credits</p>
                      <p className={`text-xs ${daysLeft < 30 ? 'text-red-500' : 'text-gray-400'}`}>
                        {daysLeft > 0 ? `${daysLeft} days left` : 'Expired'}
                      </p>
                    </div>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all ${pct >= 100 ? 'bg-green-500' : pct >= 60 ? 'bg-teal-500' : 'bg-orange-500'}`} style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{pct.toFixed(0)}% complete · {formatDate(req.start_date)} – {formatDate(req.end_date)}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter and Records Table */}
      <div className="card">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-gray-400" />
            <select value={filter} onChange={e => setFilter(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500">
              <option value="all">All Types</option>
              {CME_ACTIVITY_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <p className="text-sm text-gray-500">{filteredRecords.length} record{filteredRecords.length !== 1 ? 's' : ''}</p>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="text-center py-16">
            <Activity size={40} className="mx-auto mb-3 text-gray-200" />
            <p className="text-gray-500 font-medium">No CME records found</p>
            <p className="text-gray-400 text-sm mt-1">Start tracking your continuing education activities</p>
            <button onClick={() => setShowForm(true)} className="btn-teal mt-4 text-sm py-2 px-6">
              Add First CME Entry
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-2 font-semibold text-gray-500 text-xs uppercase tracking-wide">Activity</th>
                  <th className="text-left py-3 px-2 font-semibold text-gray-500 text-xs uppercase tracking-wide hidden md:table-cell">Type</th>
                  <th className="text-left py-3 px-2 font-semibold text-gray-500 text-xs uppercase tracking-wide">Credits</th>
                  <th className="text-left py-3 px-2 font-semibold text-gray-500 text-xs uppercase tracking-wide hidden md:table-cell">Date</th>
                  <th className="text-left py-3 px-2 font-semibold text-gray-500 text-xs uppercase tracking-wide hidden lg:table-cell">Status</th>
                  <th className="py-3 px-2 w-8"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredRecords.map(r => (
                  <tr key={r.id} className="hover:bg-gray-50 group">
                    <td className="py-3 px-2">
                      <p className="font-medium text-gray-900">{r.title}</p>
                      <p className="text-xs text-gray-400">{r.provider}</p>
                    </td>
                    <td className="py-3 px-2 hidden md:table-cell">
                      <span className="badge bg-gray-100 text-gray-600 capitalize">{r.activity_type.replace('_', ' ')}</span>
                    </td>
                    <td className="py-3 px-2">
                      <span className="font-semibold text-teal-600">{formatCredits(r.credits)}</span>
                      {r.is_mandatory && <span className="ml-1 badge bg-orange-100 text-orange-600 text-xs">Mandatory</span>}
                    </td>
                    <td className="py-3 px-2 text-gray-500 hidden md:table-cell">{formatDate(r.completion_date)}</td>
                    <td className="py-3 px-2 hidden lg:table-cell">
                      <span className={`badge ${r.verification_status === 'verified' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {r.verification_status === 'verified' ? '✓ Verified' : 'Self-reported'}
                      </span>
                    </td>
                    <td className="py-3 px-2">
                      <button onClick={() => handleDelete(r.id)} className="opacity-0 group-hover:opacity-100 p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all">
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add CME Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-gray-900">Add CME Activity</h2>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="label">Activity Title *</label>
                <input required value={form.title} onChange={e => update('title', e.target.value)} className="input-field" placeholder="e.g., Annual Cardiology Conference 2024" />
              </div>
              <div>
                <label className="label">Provider / Organizer *</label>
                <input required value={form.provider} onChange={e => update('provider', e.target.value)} className="input-field" placeholder="e.g., AIIMS, Medscape, Apollo CME" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Activity Type *</label>
                  <select required value={form.activity_type} onChange={e => update('activity_type', e.target.value)} className="input-field">
                    {CME_ACTIVITY_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Credits Earned *</label>
                  <input required type="number" min="0.25" max="100" step="0.25" value={form.credits} onChange={e => update('credits', e.target.value)} className="input-field" placeholder="e.g., 2.5" />
                </div>
              </div>
              <div>
                <label className="label">Credit Type</label>
                <select value={form.credit_type} onChange={e => update('credit_type', e.target.value)} className="input-field">
                  {['AMA PRA Category 1', 'AMA PRA Category 2', 'ACME', 'State CME', 'Other'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Completion Date *</label>
                  <input required type="date" value={form.completion_date} max={new Date().toISOString().split('T')[0]} onChange={e => update('completion_date', e.target.value)} className="input-field" />
                </div>
                <div>
                  <label className="label">Expiry Date</label>
                  <input type="date" value={form.expiry_date} onChange={e => update('expiry_date', e.target.value)} className="input-field" />
                </div>
              </div>
              <div>
                <label className="label">Notes</label>
                <textarea value={form.notes} onChange={e => update('notes', e.target.value)} className="input-field min-h-[80px] resize-none" placeholder="Any additional notes..." />
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={form.is_mandatory} onChange={e => update('is_mandatory', e.target.checked)} className="w-4 h-4 rounded border-gray-300 accent-teal-500" />
                <span className="text-sm font-medium text-gray-700">This is a mandatory CME requirement</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={submitting} className="btn-teal flex-1 flex items-center justify-center gap-2">
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
                  {submitting ? 'Saving...' : 'Add CME Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Requirement Modal */}
      {showReqForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-gray-900">Set CME Requirement</h2>
              <button onClick={() => setShowReqForm(false)} className="p-1.5 rounded-lg hover:bg-gray-100"><X size={20} /></button>
            </div>
            <form onSubmit={handleAddRequirement} className="p-6 space-y-4">
              <div>
                <label className="label">Requirement Name *</label>
                <input required value={reqForm.requirement_name} onChange={e => setReqForm(p => ({ ...p, requirement_name: e.target.value }))} className="input-field" placeholder="e.g., State License Renewal 2024-26" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Total Credits Required *</label>
                  <input required type="number" value={reqForm.total_credits_required} onChange={e => setReqForm(p => ({ ...p, total_credits_required: e.target.value }))} className="input-field" placeholder="30" />
                </div>
                <div>
                  <label className="label">License Board</label>
                  <input value={reqForm.license_board} onChange={e => setReqForm(p => ({ ...p, license_board: e.target.value }))} className="input-field" placeholder="e.g., MCI, NMC" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Start Date *</label>
                  <input required type="date" value={reqForm.start_date} onChange={e => setReqForm(p => ({ ...p, start_date: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="label">End Date *</label>
                  <input required type="date" value={reqForm.end_date} onChange={e => setReqForm(p => ({ ...p, end_date: e.target.value }))} className="input-field" />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowReqForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-teal flex-1">Save Requirement</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
