import Link from 'next/link';
import { Stethoscope, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-medical-bg flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 bg-navy-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
          <Stethoscope size={36} className="text-navy-300" />
        </div>
        <h1 className="font-display text-6xl font-bold text-navy-600 mb-2">404</h1>
        <h2 className="font-display text-2xl font-bold text-gray-900 mb-3">Page Not Found</h2>
        <p className="text-gray-500 mb-8 leading-relaxed">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex gap-3 justify-center">
          <Link href="/" className="btn-secondary flex items-center gap-2">
            <ArrowLeft size={16} />
            Go Home
          </Link>
          <Link href="/dashboard" className="btn-primary">
            Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
