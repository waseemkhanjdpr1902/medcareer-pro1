-- ============================================================
-- MedCareer Pro - Full Database Schema
-- Run this in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PROFILES TABLE (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT UNIQUE,
  phone TEXT,
  specialty TEXT,
  designation TEXT,
  institution TEXT,
  years_of_experience INTEGER DEFAULT 0,
  profile_picture_url TEXT,
  bio TEXT,
  linkedin_url TEXT,
  subscription_tier TEXT DEFAULT 'basic' CHECK (subscription_tier IN ('basic', 'professional', 'premium')),
  subscription_status TEXT DEFAULT 'inactive' CHECK (subscription_status IN ('active', 'inactive', 'cancelled', 'past_due')),
  subscription_id TEXT,
  subscription_start_date TIMESTAMPTZ,
  subscription_end_date TIMESTAMPTZ,
  razorpay_customer_id TEXT,
  onboarding_completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- ============================================================
-- CME RECORDS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS cme_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  provider TEXT NOT NULL,
  activity_type TEXT NOT NULL CHECK (activity_type IN ('conference', 'workshop', 'online_course', 'webinar', 'journal_article', 'self_study', 'teaching', 'research', 'other')),
  credits DECIMAL(5,2) NOT NULL,
  credit_type TEXT DEFAULT 'AMA PRA Category 1' CHECK (credit_type IN ('AMA PRA Category 1', 'AMA PRA Category 2', 'ACME', 'State CME', 'Other')),
  completion_date DATE NOT NULL,
  expiry_date DATE,
  certificate_url TEXT,
  notes TEXT,
  specialty_relevant TEXT[],
  is_mandatory BOOLEAN DEFAULT FALSE,
  verification_status TEXT DEFAULT 'self_reported' CHECK (verification_status IN ('self_reported', 'verified', 'pending')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE cme_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own CME records" ON cme_records FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- CME REQUIREMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS cme_requirements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  requirement_name TEXT NOT NULL,
  total_credits_required DECIMAL(6,2) NOT NULL,
  credits_per_period DECIMAL(6,2),
  period_months INTEGER DEFAULT 24,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  specialty TEXT,
  license_board TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE cme_requirements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own CME requirements" ON cme_requirements FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- CV DATA TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS cv_data (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  cv_name TEXT NOT NULL DEFAULT 'My CV',
  personal_info JSONB DEFAULT '{}',
  education JSONB DEFAULT '[]',
  work_experience JSONB DEFAULT '[]',
  skills JSONB DEFAULT '[]',
  publications JSONB DEFAULT '[]',
  awards JSONB DEFAULT '[]',
  certifications JSONB DEFAULT '[]',
  research JSONB DEFAULT '[]',
  languages JSONB DEFAULT '[]',
  references JSONB DEFAULT '[]',
  professional_memberships JSONB DEFAULT '[]',
  summary TEXT,
  is_primary BOOLEAN DEFAULT FALSE,
  last_ats_score INTEGER,
  last_scored_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE cv_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own CV data" ON cv_data FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- CV SCORES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS cv_scores (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  cv_id UUID REFERENCES cv_data(id) ON DELETE CASCADE,
  overall_score INTEGER NOT NULL,
  ats_compatibility_score INTEGER,
  keyword_score INTEGER,
  format_score INTEGER,
  content_score INTEGER,
  completeness_score INTEGER,
  feedback JSONB DEFAULT '{}',
  improvements JSONB DEFAULT '[]',
  keywords_found TEXT[],
  keywords_missing TEXT[],
  job_role_targeted TEXT,
  scored_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE cv_scores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own CV scores" ON cv_scores FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- CAREER GUIDANCE SESSIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS career_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  session_title TEXT DEFAULT 'Career Guidance Session',
  messages JSONB DEFAULT '[]',
  session_type TEXT DEFAULT 'general' CHECK (session_type IN ('general', 'career_planning', 'job_search', 'salary_negotiation', 'specialization', 'fellowship', 'research')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE career_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own career sessions" ON career_sessions FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- MOCK INTERVIEW SESSIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS interview_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  interview_type TEXT NOT NULL CHECK (interview_type IN ('clinical', 'behavioral', 'technical', 'management', 'fellowship', 'residency', 'academic', 'general')),
  specialty TEXT,
  role_applied TEXT,
  messages JSONB DEFAULT '[]',
  performance_score INTEGER,
  strengths TEXT[],
  improvements TEXT[],
  feedback_summary TEXT,
  duration_minutes INTEGER DEFAULT 0,
  status TEXT DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed', 'abandoned')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE interview_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own interview sessions" ON interview_sessions FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- SUBSCRIPTIONS TABLE (Payment Records)
-- ============================================================
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  razorpay_subscription_id TEXT UNIQUE,
  razorpay_order_id TEXT,
  razorpay_payment_id TEXT,
  plan_id TEXT NOT NULL,
  plan_name TEXT NOT NULL CHECK (plan_name IN ('professional', 'premium')),
  billing_cycle TEXT NOT NULL CHECK (billing_cycle IN ('monthly', 'yearly')),
  amount INTEGER NOT NULL,
  currency TEXT DEFAULT 'INR',
  status TEXT NOT NULL CHECK (status IN ('created', 'authenticated', 'active', 'pending', 'halted', 'cancelled', 'completed', 'expired')),
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own subscriptions" ON subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Service role can manage subscriptions" ON subscriptions FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- USAGE TRACKING TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS usage_tracking (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  feature TEXT NOT NULL,
  month_year TEXT NOT NULL,
  count INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, feature, month_year)
);

ALTER TABLE usage_tracking ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own usage" ON usage_tracking FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Service role can manage usage" ON usage_tracking FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- TRIGGERS
-- ============================================================

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NEW.email
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_cme_records_updated_at BEFORE UPDATE ON cme_records FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_cv_data_updated_at BEFORE UPDATE ON cv_data FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_career_sessions_updated_at BEFORE UPDATE ON career_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_interview_sessions_updated_at BEFORE UPDATE ON interview_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
