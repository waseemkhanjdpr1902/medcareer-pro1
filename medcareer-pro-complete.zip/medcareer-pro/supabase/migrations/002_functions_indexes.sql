-- ============================================================
-- MedCareer Pro — Migration 002
-- Run AFTER 001_schema.sql in Supabase SQL Editor
-- ============================================================

-- ============================================================
-- increment_usage RPC function (called from API routes)
-- ============================================================
CREATE OR REPLACE FUNCTION increment_usage(
  p_user_id UUID,
  p_feature TEXT,
  p_month_year TEXT
)
RETURNS void AS $$
BEGIN
  INSERT INTO usage_tracking (user_id, feature, month_year, count, updated_at)
  VALUES (p_user_id, p_feature, p_month_year, 1, NOW())
  ON CONFLICT (user_id, feature, month_year)
  DO UPDATE SET
    count = usage_tracking.count + 1,
    updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute to authenticated role
GRANT EXECUTE ON FUNCTION increment_usage(UUID, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION increment_usage(UUID, TEXT, TEXT) TO service_role;

-- ============================================================
-- PERFORMANCE INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_cme_records_user_id ON cme_records(user_id);
CREATE INDEX IF NOT EXISTS idx_cme_records_completion_date ON cme_records(completion_date DESC);
CREATE INDEX IF NOT EXISTS idx_cv_scores_user_id ON cv_scores(user_id);
CREATE INDEX IF NOT EXISTS idx_cv_scores_scored_at ON cv_scores(scored_at DESC);
CREATE INDEX IF NOT EXISTS idx_career_sessions_user_id ON career_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_career_sessions_updated_at ON career_sessions(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_interview_sessions_user_id ON interview_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_interview_sessions_created_at ON interview_sessions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_usage_tracking_user_feature_month ON usage_tracking(user_id, feature, month_year);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);

-- ============================================================
-- SERVICE ROLE POLICY for usage_tracking INSERT/UPDATE
-- ============================================================
DROP POLICY IF EXISTS "Service role can manage usage" ON usage_tracking;
CREATE POLICY "Authenticated users can upsert own usage" ON usage_tracking
  FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- VIEW: user_subscription_summary (helper for dashboards)
-- ============================================================
CREATE OR REPLACE VIEW user_subscription_summary AS
SELECT
  p.id AS user_id,
  p.full_name,
  p.email,
  p.specialty,
  p.subscription_tier,
  p.subscription_status,
  p.subscription_end_date,
  COALESCE(cme.total_credits, 0) AS total_cme_credits,
  COALESCE(cme.total_activities, 0) AS total_cme_activities,
  COALESCE(cv.last_score, 0) AS last_cv_score,
  COALESCE(interviews.total_sessions, 0) AS total_interview_sessions
FROM profiles p
LEFT JOIN (
  SELECT user_id, SUM(credits) AS total_credits, COUNT(*) AS total_activities
  FROM cme_records
  GROUP BY user_id
) cme ON cme.user_id = p.id
LEFT JOIN (
  SELECT DISTINCT ON (user_id) user_id, overall_score AS last_score
  FROM cv_scores
  ORDER BY user_id, scored_at DESC
) cv ON cv.user_id = p.id
LEFT JOIN (
  SELECT user_id, COUNT(*) AS total_sessions
  FROM interview_sessions
  GROUP BY user_id
) interviews ON interviews.user_id = p.id;

-- ============================================================
-- STORAGE BUCKET for CME certificates
-- ============================================================
-- Run this in Supabase Dashboard → Storage, or uncomment below:
-- INSERT INTO storage.buckets (id, name, public) VALUES ('cme-certificates', 'cme-certificates', false);
-- CREATE POLICY "Users can upload own certificates" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'cme-certificates' AND auth.uid()::text = (storage.foldername(name))[1]);
-- CREATE POLICY "Users can read own certificates" ON storage.objects FOR SELECT USING (bucket_id = 'cme-certificates' AND auth.uid()::text = (storage.foldername(name))[1]);

-- ============================================================
-- SAMPLE DATA SEED (optional — comment out for production)
-- ============================================================
-- INSERT INTO cme_records (user_id, title, provider, activity_type, credits, completion_date)
-- SELECT id, 'Annual Cardiology Conference 2024', 'CSI', 'conference', 8, '2024-11-15'
-- FROM profiles LIMIT 1;
