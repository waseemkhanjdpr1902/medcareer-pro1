'use client';

import Link from 'next/link';
import { Lock, Zap } from 'lucide-react';
import { SubscriptionTier } from '@/lib/utils';

interface UpgradeGateProps {
  requiredTier: 'professional' | 'premium';
  currentTier: SubscriptionTier;
  featureName: string;
  description?: string;
  children: React.ReactNode;
}

export function UpgradeGate({
  requiredTier,
  currentTier,
  featureName,
  description,
  children,
}: UpgradeGateProps) {
  const tierOrder = { basic: 0, professional: 1, premium: 2 };
  const hasAccess = tierOrder[currentTier] >= tierOrder[requiredTier];

  if (hasAccess) return <>{children}</>;

  return (
    <div className="relative">
      {/* Blurred preview */}
      <div className="pointer-events-none select-none opacity-30 blur-sm">
        {children}
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 flex items-center justify-center bg-white/60 backdrop-blur-[2px] rounded-2xl">
        <div className="text-center px-8 py-6 max-w-xs">
          <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Lock size={22} className="text-amber-500" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-1">{featureName}</h3>
          <p className="text-sm text-gray-500 mb-4 leading-relaxed">
            {description || `This feature requires a ${requiredTier} plan or higher.`}
          </p>
          <Link
            href={`/pricing?plan=${requiredTier}`}
            className="inline-flex items-center gap-2 bg-teal-500 text-white px-5 py-2 rounded-xl font-semibold text-sm hover:bg-teal-600 transition-colors"
          >
            <Zap size={14} />
            Upgrade to {requiredTier.charAt(0).toUpperCase() + requiredTier.slice(1)}
          </Link>
        </div>
      </div>
    </div>
  );
}
