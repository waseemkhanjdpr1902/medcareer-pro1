import { cn } from '@/lib/utils';

interface ScoreRingProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  className?: string;
}

export function ScoreRing({
  score,
  size = 120,
  strokeWidth = 8,
  label,
  className,
}: ScoreRingProps) {
  const r = (size / 2) - strokeWidth;
  const circumference = 2 * Math.PI * r;
  const offset = circumference - (Math.min(100, Math.max(0, score)) / 100) * circumference;

  const color =
    score >= 80 ? '#22c55e'
    : score >= 60 ? '#f59e0b'
    : '#ef4444';

  const labelText =
    score >= 80 ? 'Excellent'
    : score >= 65 ? 'Good'
    : score >= 50 ? 'Fair'
    : 'Needs Work';

  const cx = size / 2;
  const cy = size / 2;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={cn('block', className)}
    >
      {/* Background track */}
      <circle
        cx={cx} cy={cy} r={r}
        fill="none"
        stroke="#f1f5f9"
        strokeWidth={strokeWidth}
      />
      {/* Progress arc */}
      <circle
        cx={cx} cy={cy} r={r}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${cx} ${cy})`}
        style={{ transition: 'stroke-dashoffset 1.2s ease-out, stroke 0.4s' }}
      />
      {/* Score text */}
      <text
        x={cx} y={cy - 4}
        textAnchor="middle"
        fontSize={size * 0.18}
        fontWeight="700"
        fill="#1A202C"
        fontFamily="DM Serif Display, Georgia, serif"
      >
        {score}
      </text>
      {/* Sub-label */}
      <text
        x={cx} y={cy + size * 0.13}
        textAnchor="middle"
        fontSize={size * 0.09}
        fill="#94a3b8"
        fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
      >
        {label ?? labelText}
      </text>
    </svg>
  );
}
