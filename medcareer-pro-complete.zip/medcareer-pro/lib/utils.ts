import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type SubscriptionTier = 'basic' | 'professional' | 'premium';

export interface SubscriptionLimits {
  cme_entries: number | 'unlimited';
  cv_scores_per_month: number | 'unlimited';
  cv_builders: number | 'unlimited';
  career_sessions: number | 'unlimited';
  interview_sessions_per_month: number | 'unlimited';
  ai_cv_optimization: boolean;
  advanced_analytics: boolean;
  priority_support: boolean;
  export_pdf: boolean;
}

export const SUBSCRIPTION_LIMITS: Record<SubscriptionTier, SubscriptionLimits> = {
  basic: {
    cme_entries: 10,
    cv_scores_per_month: 1,
    cv_builders: 1,
    career_sessions: 3,
    interview_sessions_per_month: 2,
    ai_cv_optimization: false,
    advanced_analytics: false,
    priority_support: false,
    export_pdf: false,
  },
  professional: {
    cme_entries: 'unlimited',
    cv_scores_per_month: 10,
    cv_builders: 3,
    career_sessions: 'unlimited',
    interview_sessions_per_month: 15,
    ai_cv_optimization: true,
    advanced_analytics: true,
    priority_support: false,
    export_pdf: true,
  },
  premium: {
    cme_entries: 'unlimited',
    cv_scores_per_month: 'unlimited',
    cv_builders: 'unlimited',
    career_sessions: 'unlimited',
    interview_sessions_per_month: 'unlimited',
    ai_cv_optimization: true,
    advanced_analytics: true,
    priority_support: true,
    export_pdf: true,
  },
};

export const PRICING = {
  professional: {
    monthly: { amount: 99900, display: '₹999', period: 'month' },
    yearly: { amount: 999900, display: '₹9,999', period: 'year', savings: '₹1,989' },
  },
  premium: {
    monthly: { amount: 199900, display: '₹1,999', period: 'month' },
    yearly: { amount: 1999900, display: '₹19,999', period: 'year', savings: '₹3,989' },
  },
};

export function canUseFeature(
  tier: SubscriptionTier,
  feature: keyof SubscriptionLimits,
  currentUsage?: number
): boolean {
  const limits = SUBSCRIPTION_LIMITS[tier];
  const limit = limits[feature];

  if (typeof limit === 'boolean') return limit;
  if (limit === 'unlimited') return true;
  if (currentUsage !== undefined) return currentUsage < (limit as number);
  return true;
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function formatCredits(credits: number): string {
  return credits % 1 === 0 ? credits.toString() : credits.toFixed(1);
}

export function getCurrentMonthYear(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export function getScoreColor(score: number): string {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-yellow-600';
  return 'text-red-600';
}

export function getScoreBg(score: number): string {
  if (score >= 80) return 'bg-green-100';
  if (score >= 60) return 'bg-yellow-100';
  return 'bg-red-100';
}

export function getScoreLabel(score: number): string {
  if (score >= 80) return 'Excellent';
  if (score >= 65) return 'Good';
  if (score >= 50) return 'Fair';
  return 'Needs Work';
}

export const MEDICAL_SPECIALTIES = [
  'Anaesthesiology', 'Cardiology', 'Cardiothoracic Surgery', 'Critical Care Medicine',
  'Dermatology', 'Emergency Medicine', 'Endocrinology', 'Family Medicine',
  'Gastroenterology', 'General Medicine', 'General Surgery', 'Geriatrics',
  'Haematology', 'Infectious Disease', 'Internal Medicine', 'Nephrology',
  'Neurology', 'Neurosurgery', 'Obstetrics & Gynaecology', 'Oncology',
  'Ophthalmology', 'Orthopaedic Surgery', 'Paediatrics', 'Pathology',
  'Pharmacology', 'Plastic Surgery', 'Psychiatry', 'Pulmonology',
  'Radiology', 'Rheumatology', 'Sports Medicine', 'Urology', 'Vascular Surgery', 'Other',
];

export const CME_ACTIVITY_TYPES = [
  { value: 'conference', label: 'Conference' },
  { value: 'workshop', label: 'Workshop' },
  { value: 'online_course', label: 'Online Course' },
  { value: 'webinar', label: 'Webinar' },
  { value: 'journal_article', label: 'Journal Article Review' },
  { value: 'self_study', label: 'Self-Study' },
  { value: 'teaching', label: 'Teaching/Lecturing' },
  { value: 'research', label: 'Research Activity' },
  { value: 'other', label: 'Other' },
];
